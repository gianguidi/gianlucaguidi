#!/usr/bin/env Rscript
# =============================================================================
# Title   : Demographics + Vulnerabilities vs PM2.5 thresholds (tract-level)
# Author  : Michael Cork
# Date    : 2025-10-14
#
# Purpose :
#   - Join PM2.5 increments (from InMAP post-process) to tract-level
#     demographic and vulnerability indicators, then summarize (population-
#     weighted) across user-chosen PM2.5 thresholds.
#
# External indicators added (tract level):
#   1) CDC PLACES – Adult current asthma prevalence (%):
#        - File: "data/CDC_Places_Census_tract.csv"
#        - Source: CDC PLACES, GIS-friendly tract dataset (latest release).
#        - Variable used: CASTHMA_CrudePrev (%). If CASTHMA_AdjPrev exists,
#          you may prefer the age-adjusted prevalence for cross-area comparability.
#        - Meaning: Estimated percent of adults (18+) who currently have asthma.
#
#   2) CDC/ATSDR SVI 2022 – Social Vulnerability Index (percentiles):
#        - File: "data/SVI_2022_US.csv"
#        - Source: CDC/ATSDR Social Vulnerability Index (SVI), 2022, tract CSV.
#        - Variables used (0–1 in source):
#           * RPL_THEMES  -> SVI_overall      (overall vulnerability percentile)
#           * RPL_THEME1  -> SVI_SES          (Socioeconomic)
#           * RPL_THEME2  -> SVI_HH           (Household composition & disability)
#           * RPL_THEME3  -> SVI_MINLANG      (Minority status & language)
#           * RPL_THEME4  -> SVI_HOUSTR       (Housing type & transportation)
#          Also:
#           * EP_NOVEH    -> pct_no_vehicle_svi (% households with no vehicle)
#        - Meaning: Percentiles (0–100) indicating relative vulnerability
#          compared to all U.S. tracts (higher = more vulnerable).
#
# Outputs :
#   - <out_dir>/demographics_summary_plus.csv
#
# Notes   :
#   - Population-weighted means use tract ACS total population as weights.
#   - "National Average" for ACS metrics comes from ACS (US table).
#   - For SVI/asthma/vehicle access, the "National Average" column is
#     computed as the population-weighted mean across the tracts present in
#     this analysis (since national ACS-by-tract is not pulled here).
#   - If STUSPS is missing in tracts_with_pm25.csv, a fallback derives it
#     from GEOID using tidycensus::fips_codes.
# =============================================================================

suppressPackageStartupMessages({
  library(dplyr); library(readr); library(purrr)
  library(tidycensus); library(stringr); library(tidyr); library(sf)
})

options(stringsAsFactors = FALSE)

# -------- Run context --------
timestamp  <- "25_11_10"
identifier <- "fluvanna"

timestamp     <- "25_10_24"
identifier    <- "tucker"

out_dir    <- file.path("output", paste0(timestamp, "_", identifier))
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

tracts_csv  <- file.path(out_dir, "tracts_with_pm25.csv")
summary_csv <- file.path(out_dir, "demographics_summary_plus.csv")

# External indicator files
places_csv  <- "data/CDC_Places_Census_tract.csv"  # PLACES (tract GIS CSV)
svi_csv     <- "data/SVI_2022_US.csv"              # SVI 2022 tract CSV

# PM2.5 thresholds to summarize (µg/m^3)
thresholds <- c(1e-3, 1e-2)

# ---- Census API key ----
if (nzchar(Sys.getenv("CENSUS_API_KEY"))) {
  tidycensus::census_api_key(Sys.getenv("CENSUS_API_KEY"), install = FALSE)
} else stop("Set CENSUS_API_KEY env var before running.")

# ---- Load tracts + ΔPM2.5 ----
tracts_pm <- readr::read_csv(tracts_csv, show_col_types = FALSE) %>%
  mutate(GEOID = as.character(GEOID))

# Ensure state abbrev (STUSPS); derive from GEOID if missing
if (!("STUSPS" %in% names(tracts_pm)) || all(is.na(tracts_pm$STUSPS))) {
  st_xwalk <- tidycensus::fips_codes %>% distinct(state_code, STUSPS = state)
  tracts_pm <- tracts_pm %>%
    mutate(STATEFP = substr(GEOID, 1, 2)) %>%
    left_join(st_xwalk, by = c("STATEFP" = "state_code")) %>%
    select(-STATEFP)
}

# ---- External indicators ----

# PLACES adult asthma (%). If age-adjusted available, prefer it; else crude.
asthma_df <- read_csv(places_csv, show_col_types = FALSE) %>%
  transmute(
    GEOID = str_pad(TractFIPS, 11, "left", "0"),
    asthma_prev = suppressWarnings(as.numeric(CASTHMA_CrudePrev))
    # If you have CASTHMA_AdjPrev, swap that in here.
  )

# SVI 2022: overall percentile (0–100) + households-no-vehicle (%)
# --- Clean SVI ingest: drop sentinel negatives BEFORE scaling ---
svi_raw <- readr::read_csv(svi_csv, show_col_types = FALSE) %>%
  dplyr::transmute(
    GEOID       = as.character(FIPS),
    RPL_THEMES  = suppressWarnings(as.numeric(RPL_THEMES)),
    EP_NOVEH    = suppressWarnings(as.numeric(EP_NOVEH)),
    E_TOTPOP    = suppressWarnings(as.numeric(E_TOTPOP))
  )

# Convert sentinel negatives (-999, -999.9, etc.) to NA
svi_clean <- svi_raw %>%
  mutate(
    RPL_THEMES  = ifelse(RPL_THEMES  < 0, NA_real_, RPL_THEMES),
    EP_NOVEH    = ifelse(EP_NOVEH    < 0, NA_real_, EP_NOVEH),
    E_TOTPOP    = ifelse(E_TOTPOP    < 0, NA_real_, E_TOTPOP)
  ) %>%
  # Keep only valid tract GEOIDs
  dplyr::filter(nchar(GEOID) == 11)

# Create analysis fields AFTER cleaning
# Keep E_TOTPOP for optional true-national weighting if desired.
svi <- svi_clean %>%
  transmute(
    GEOID,
    SVI_overall    = 100 * RPL_THEMES,   # now 0–100
    pct_no_vehicle = EP_NOVEH,           # already in percent units
    svi_totpop     = E_TOTPOP            # population for weighting
  ) %>%
  filter(!is.na(SVI_overall), !is.na(pct_no_vehicle))


# Join indicators to analysis tracts
tracts_pm <- tracts_pm %>%
  left_join(asthma_df, by = "GEOID") %>%
  left_join(svi,       by = "GEOID")

# ---- States present in analysis (AUTO; no hard-coding) ----
states_needed <- tracts_pm %>%
  distinct(STUSPS) %>%
  pull(STUSPS) %>%
  { .[!is.na(.) & . != ""] } %>%
  sort()
message("ACS states in analysis: ", paste(states_needed, collapse = ", "))
states_needed <- "WV"

# ---- ACS variables (2022 5-yr) ----
vars <- c(
  total_pop        = "B01003_001",
  race_total       = "B02001_001",
  pct_white        = "B02001_002",
  pct_black        = "B02001_003",
  pct_asian        = "B02001_005",
  hisp_total       = "B03003_001",
  pct_hispanic     = "B03003_003",
  poverty_total    = "B17001_001",
  poverty_below    = "B17001_002",
  med_household_income = "B19013_001",
  med_property_value   = "B25077_001",
  # Age 65+ bins (male/female)
  age_65_m_65_66 = "B01001_020",
  age_65_m_67_69 = "B01001_021",
  age_65_m_70_74 = "B01001_022",
  age_65_m_75_79 = "B01001_023",
  age_65_m_80_84 = "B01001_024",
  age_65_m_85_up = "B01001_025",
  age_65_f_65_66 = "B01001_044",
  age_65_f_67_69 = "B01001_045",
  age_65_f_70_74 = "B01001_046",
  age_65_f_75_79 = "B01001_047",
  age_65_f_80_84 = "B01001_048",
  age_65_f_85_up = "B01001_049"
)

get_acs_state_tracts <- function(st) {
  tidycensus::get_acs(
    geography = "tract", state = st, variables = vars,
    year = 2022, survey = "acs5", output = "wide", geometry = FALSE
  )
}
acs_tracts <- purrr::map_dfr(states_needed, get_acs_state_tracts) %>%
  filter(total_popE > 0)

acs_us <- tidycensus::get_acs(
  geography = "us", variables = vars,
  year = 2022, survey = "acs5", output = "wide", geometry = FALSE
) %>% slice(1)

# ---- Build tract-level ACS metrics ----
demog_tracts <- acs_tracts %>%
  transmute(
    GEOID,
    population = total_popE,
    # Race shares: use B02001 denominator
    pct_white   = 100 * pct_whiteE   / pmax(race_totalE, 1),
    pct_black   = 100 * pct_blackE   / pmax(race_totalE, 1),
    pct_asian   = 100 * pct_asianE   / pmax(race_totalE, 1),
    # Hispanic share: use B03003 denominator
    pct_hispanic= 100 * pct_hispanicE / pmax(hisp_totalE, 1),
    # Poverty
    pct_poverty = 100 * poverty_belowE / pmax(poverty_totalE, 1),
    # Age 65+
    pct_age_65 = 100 * (
      age_65_m_65_66E + age_65_m_67_69E + age_65_m_70_74E +
        age_65_m_75_79E + age_65_m_80_84E + age_65_m_85_upE +
        age_65_f_65_66E + age_65_f_67_69E + age_65_f_70_74E +
        age_65_f_75_79E + age_65_f_80_84E + age_65_f_85_upE
    ) / pmax(total_popE, 1),
    med_household_income = med_household_incomeE,
    med_property_value   = med_property_valueE
  )

# ---- Join ACS metrics to analysis tracts ----
tracts_demo <- tracts_pm %>%
  select(GEOID, STUSPS, pm25_weighted, asthma_prev, SVI_overall, pct_no_vehicle) %>%
  left_join(demog_tracts, by = "GEOID")

# ---- Baselines ----
# ACS national (from US table)
nat <- list(
  population           = acs_us$total_popE,
  pct_white            = 100 * acs_us$pct_whiteE    / pmax(acs_us$race_totalE, 1),
  pct_black            = 100 * acs_us$pct_blackE    / pmax(acs_us$race_totalE, 1),
  pct_asian            = 100 * acs_us$pct_asianE    / pmax(acs_us$race_totalE, 1),
  pct_hispanic         = 100 * acs_us$pct_hispanicE / pmax(acs_us$hisp_totalE, 1),
  pct_poverty          = 100 * acs_us$poverty_belowE / pmax(acs_us$poverty_totalE, 1),
  pct_age_65           = 100 * (
    acs_us$age_65_m_65_66E + acs_us$age_65_m_67_69E + acs_us$age_65_m_70_74E +
      acs_us$age_65_m_75_79E + acs_us$age_65_m_80_84E + acs_us$age_65_m_85_upE +
      acs_us$age_65_f_65_66E + acs_us$age_65_f_67_69E + acs_us$age_65_f_70_74E +
      acs_us$age_65_f_75_79E + acs_us$age_65_f_80_84E + acs_us$age_65_f_85_upE
  ) / pmax(acs_us$total_popE, 1),
  med_household_income = acs_us$med_household_incomeE,
  med_property_value   = acs_us$med_property_valueE
)

# Weighted-mean helper
wmean <- function(x, w) {
  if (length(x) != length(w)) stop("wmean(): x and w must have same length.")
  if (all(is.na(x)) || all(is.na(w))) return(NA_real_)
  w <- ifelse(is.na(w), 0, w)
  if (sum(w, na.rm = TRUE) == 0) return(NA_real_)
  stats::weighted.mean(x, w, na.rm = TRUE)
}

# "National Average" for SVI/asthma/no-vehicle:
# CURRENT default: across analysis tracts (footprint). To compute a true
# national benchmark instead, see the commented block below.
us_plus <- tibble(
  pct_no_vehicle = wmean(tracts_demo$pct_no_vehicle, tracts_demo$population),
  SVI_overall    = wmean(tracts_demo$SVI_overall,    tracts_demo$population),
  asthma_prev    = wmean(tracts_demo$asthma_prev,    tracts_demo$population)
)

# # Optional TRUE national means (uncomment if you want to use them)
us_plus <- svi %>%
  # join PLACES asthma to SVI to get national population weights
  select(GEOID, SVI_overall, pct_no_vehicle, svi_totpop) %>%
  left_join(asthma_df, by = "GEOID") %>%
  summarize(
    pct_no_vehicle = wmean(pct_no_vehicle, svi_totpop),
    SVI_overall    = wmean(SVI_overall,    svi_totpop),
    asthma_prev    = wmean(asthma_prev,    svi_totpop)
  )

# ---- Metrics to report (row order) ----
metrics <- c(
  "Total Population Affected",
  "Poverty Rate (%)",
  "White (%)",
  "Black (%)",
  "Hispanic (%)",
  "Asian (%)",
  "Age 65+ (%)",
  "Median Household Income ($)",
  "Median Property Value ($)",
  "Households with No Vehicle (%)",
  "SVI Overall (0–100)",
  "Adult Asthma Prevalence (%)"
)

compute_group_long <- function(df) {
  tibble(
    Metric = metrics,
    Value = c(
      sum(df$population, na.rm = TRUE),
      wmean(df$pct_poverty,  df$population),
      wmean(df$pct_white,    df$population),
      wmean(df$pct_black,    df$population),
      wmean(df$pct_hispanic, df$population),
      wmean(df$pct_asian,    df$population),
      wmean(df$pct_age_65,   df$population),
      wmean(df$med_household_income, df$population),
      wmean(df$med_property_value,   df$population),
      wmean(df$pct_no_vehicle, df$population),
      wmean(df$SVI_overall,    df$population),
      wmean(df$asthma_prev,    df$population)
    )
  )
}

# ---- Threshold columns (> ... µg/m^3) ----
th_tbls <- purrr::map(thresholds, function(th) {
  df_sub <- tracts_demo %>% filter(!is.na(pm25_weighted), pm25_weighted > th)
  colname <- paste0(">", format(th, scientific = FALSE, trim = TRUE))
  compute_group_long(df_sub) %>% rename(!!colname := Value)
})
threshold_block <- purrr::reduce(th_tbls, left_join, by = "Metric")

# ---- State and national columns ----
state_label <- paste0("In-State Average (", paste(states_needed, collapse = ","), ")")

state_col <- compute_group_long(
  tracts_demo %>% filter(STUSPS %in% states_needed)
) %>% rename(!!state_label := Value)

us_col <- tibble(
  Metric = metrics,
  `National Average` = c(
    nat$population,
    nat$pct_poverty,
    nat$pct_white,
    nat$pct_black,
    nat$pct_hispanic,
    nat$pct_asian,
    nat$pct_age_65,
    nat$med_household_income,
    nat$med_property_value,
    us_plus$pct_no_vehicle,
    us_plus$SVI_overall,
    us_plus$asthma_prev
  )
)

# ---- Build final table ----
summary_tbl <- threshold_block %>%
  left_join(state_col, by = "Metric") %>%
  left_join(us_col,   by = "Metric") %>%
  mutate(
    across(starts_with(">"), ~ case_when(
      Metric == "Total Population Affected" ~ round(.x, -2),
      Metric %in% c("Median Household Income ($)", "Median Property Value ($)") ~ round(.x, -2),
      TRUE ~ round(.x, 1)
    )),
    !!state_label := case_when(
      Metric == "Total Population Affected" ~ round(.data[[state_label]], -2),
      Metric %in% c("Median Household Income ($)", "Median Property Value ($)") ~ round(.data[[state_label]], -2),
      TRUE ~ round(.data[[state_label]], 1)
    ),
    `National Average` = case_when(
      Metric == "Total Population Affected" ~ round(`National Average`, -2),
      Metric %in% c("Median Household Income ($)", "Median Property Value ($)") ~ round(`National Average`, -2),
      TRUE ~ round(`National Average`, 1)
    )
  )

# ---- Write + print ----
readr::write_csv(summary_tbl, summary_csv)
message("✔ Wrote: ", summary_csv)
print(summary_tbl, n = nrow(summary_tbl))
