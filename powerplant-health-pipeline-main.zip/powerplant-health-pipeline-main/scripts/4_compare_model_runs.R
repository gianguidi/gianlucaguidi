# -------------------------------------------------------------------------
# Title   : Compare County-Level PM2.5 Across Two InMAP Runs
# Author  : Michael Cork (generated helper script)
# Purpose : Load county outputs for two runs (tucker vs timberman),
#           compare population-weighted PM2.5 at the county level,
#           and export a clean comparison table.
# -------------------------------------------------------------------------

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(stringr)
  library(scales)
})

# ---------------------------
# 1) CONFIG
# ---------------------------

# Original run (Tucker proposed site)
timestamp_a  <- "25_10_24"
identifier_a <- "tucker"

# New run (Alternative site: Timberman Ridge)
timestamp_b  <- "26_01_05"
identifier_b <- "timberman"

# Where your postprocess outputs live
out_dir_a <- file.path("output", paste0(timestamp_a, "_", identifier_a))
out_dir_b <- file.path("output", paste0(timestamp_b, "_", identifier_b))

# Inputs (prefer county_burden_ranked.csv if present; else fall back to counties_with_pm25.csv)
file_a_burden <- file.path(out_dir_a, "county_burden_ranked.csv")
file_b_burden <- file.path(out_dir_b, "county_burden_ranked.csv")
file_a_county <- file.path(out_dir_a, "counties_with_pm25.csv")
file_b_county <- file.path(out_dir_b, "counties_with_pm25.csv")

# Output
out_dir_comp <- file.path("output", paste0(timestamp_b, "_", identifier_b), "comparisons")
dir.create(out_dir_comp, recursive = TRUE, showWarnings = FALSE)

out_csv <- file.path(out_dir_comp, sprintf(
  "county_pm25_comparison_%s_%s_vs_%s_%s.csv",
  timestamp_a, identifier_a, timestamp_b, identifier_b
))

# ---------------------------
# 2) HELPERS
# ---------------------------

# Safe read: choose burden file if it exists, else counties_with_pm25.csv
read_county_tbl <- function(burden_path, county_path, label) {
  if (file.exists(burden_path)) {
    df <- readr::read_csv(burden_path, show_col_types = FALSE) %>%
      mutate(source = "county_burden_ranked")
  } else {
    stopifnot(file.exists(county_path))
    df <- readr::read_csv(county_path, show_col_types = FALSE) %>%
      mutate(source = "counties_with_pm25")
  }
  
  # Normalize to a common schema
  # - burden file has: county, state, population, share_total_exposure, avg_increment
  # - counties_with_pm25 has: GEOID, STATE_NAME, NAMELSAD, total_pop, pm25_weighted, ...
  if ("avg_increment" %in% names(df)) {
    out <- df %>%
      transmute(
        county = county,
        state  = state,
        population = suppressWarnings(as.numeric(population)),
        share_total_exposure = suppressWarnings(as.numeric(share_total_exposure)),
        pm25 = suppressWarnings(as.numeric(avg_increment))
      )
  } else {
    # Try to infer county + state fields robustly
    out <- df %>%
      transmute(
        # NAMELSAD is like "Grant County" (keep it)
        county = coalesce(.data$NAMELSAD, .data$NAME),
        state  = coalesce(.data$STATE_NAME, .data$STATEFP, NA_character_),
        population = suppressWarnings(as.numeric(.data$total_pop)),
        share_total_exposure = NA_real_,
        pm25 = suppressWarnings(as.numeric(.data$pm25_weighted))
      )
  }
  
  out %>%
    mutate(
      run = label,
      # Key to join on; keep it simple and robust
      county_state_key = str_to_lower(paste0(county, " | ", state))
    )
}

pct_change <- function(new, old) {
  ifelse(is.na(old) | old == 0, NA_real_, 100 * (new - old) / old)
}

# ---------------------------
# 3) LOAD BOTH RUNS
# ---------------------------

a <- read_county_tbl(file_a_burden, file_a_county, label = identifier_a)
b <- read_county_tbl(file_b_burden, file_b_county, label = identifier_b)

# ---------------------------
# 4) DEFINE "TOP COUNTIES" SET
# ---------------------------
# You have options; pick one and comment out the others.

# # Option 1: union of top N counties by avg PM2.5 in either run
# top_n <- 15
# top_keys <- union(
#   a %>% arrange(desc(pm25)) %>% slice_head(n = top_n) %>% pull(county_state_key),
#   b %>% arrange(desc(pm25)) %>% slice_head(n = top_n) %>% pull(county_state_key)
# )

# Option 2: top N by exposure burden share (only works if burden_ranked exists)
# top_n <- 15
# top_keys <- union(
#   a %>% arrange(desc(share_total_exposure)) %>% slice_head(n = top_n) %>% pull(county_state_key),
#   b %>% arrange(desc(share_total_exposure)) %>% slice_head(n = top_n) %>% pull(county_state_key)
# )

# Option 3: only the top N counties from the original run (tucker)
top_n <- 10
top_keys <- a %>% arrange(desc(pm25)) %>% slice_head(n = top_n) %>% pull(county_state_key)

# ---------------------------
# 5) JOIN + COMPARE
# ---------------------------

comp <- a %>%
  filter(county_state_key %in% top_keys) %>%
  select(county, state, population_a = population, pm25_a = pm25) %>%
  full_join(
    b %>%
      filter(county_state_key %in% top_keys) %>%
      select(county, state, population_b = population, pm25_b = pm25),
    by = c("county", "state")
  ) %>%
  mutate(
    # Prefer population from B if available (newer run), else A
    population = coalesce(population_b, population_a),
    delta_pm25 = pm25_b - pm25_a,
    pct_delta  = pct_change(pm25_b, pm25_a)
  ) %>%
  arrange(desc(pm25_a)) %>%
  transmute(
    State = state,
    County = county,
    Population = comma(round(population)),
    `Avg ΔPM2.5 (Ridgeline) (µg/m³)`    = signif(pm25_a, 4),
    `Avg ΔPM2.5 (Timberman) (µg/m³)` = signif(pm25_b, 4),
    `Change (µg/m³)`                = signif(delta_pm25, 4),
    `Change (%)`                    = ifelse(is.na(pct_delta), NA_character_, paste0(round(pct_delta, 1), "%"))
  )

# ---------------------------
# 6) SAVE
# ---------------------------

readr::write_csv(comp, out_csv)
message("✔ Wrote county comparison table: ", out_csv)

# Print preview to console
print(comp, n = min(25, nrow(comp)))
