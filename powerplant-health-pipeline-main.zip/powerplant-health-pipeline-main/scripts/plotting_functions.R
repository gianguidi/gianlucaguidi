#' Plot a PM2.5 map at tract / county / grid / town level with optional minimap
#'
#' @param tracts_out   sf; tracts with cols `pm25_weighted`, `STATEFP`, `COUNTYFP` (needed for "tract").
#' @param counties_out sf; counties with cols `pm25_weighted`, `STATEFP`, `COUNTYFP`, `NAME`.
#' @param counties_sf  sf; canonical counties with `STATEFP`, `COUNTYFP`, `NAME` (used for county label geometry).
#' @param plant        sf; point (or small sf) for the plant location.
#' @param target_crs   integer or CRS; target projection (e.g., 5070).
#' @param label_threshold numeric; **single threshold** used to determine which features are “hot”
#'   and to compute the focus region:
#'   - "tract": a county is labeled if ANY tract in it has pm25_weighted ≥ threshold.
#'   - "county": a county is labeled if county pm25_weighted ≥ threshold.
#'   - "grid": a county is labeled if ANY grid cell has `grid_fill_col` ≥ threshold.
#'   - **"town"**: a town is plotted if town pm25_weighted ≥ threshold (labels show town names).
#' @param box_expand   numeric ≥ 0; fractional expansion of bbox (default 0.1).
#' @param aggregation_level character; one of "tract", "county", "grid", **"town"**.
#' @param minimap_region character; one of "wv", "se", "us", "midsouth" (default "wv").
#' @param minimap_include logical; include the minimap inset? (default TRUE).
#' @param minimap_x,minimap_y,minimap_width,minimap_height numeric in [0,1]; minimap placement/size.
#' @param cells        sf; (required for "grid") grid cells sf for choropleth.
#' @param grid_fill_col character; (grid) column in `cells` used for fill (default "TotalPM25").
#' @param towns_exposed_sf sf; (required for **"town"**) towns with `pm25_weighted` and `NAME` columns,
#'   already filtered to the states of interest (ACS-matched if that’s your policy).
#'
#' @return A ggplot/cowplot object (print to view; use ggsave() to save).
#' @import sf dplyr ggplot2 ggrepel tigris cowplot tibble scales grid
make_pm25_map_with_minimap <- function(
    tracts_out,
    counties_out,
    counties_sf,
    plant,
    target_crs,
    label_threshold,
    box_expand = 0.1,
    aggregation_level = c("tract", "county", "grid", "town"),
    minimap_region = c("wv", "se", "midsouth", "us"),
    minimap_include = TRUE,
    minimap_x = 0.80,
    minimap_y = 0.02,
    minimap_width  = 0.18,
    minimap_height = 0.18,
    cells = NULL,
    grid_fill_col = "TotalPM25",
    towns_exposed_sf = NULL
) {
  stopifnot(requireNamespace("sf", quietly = TRUE),
            requireNamespace("dplyr", quietly = TRUE),
            requireNamespace("ggplot2", quietly = TRUE),
            requireNamespace("ggrepel", quietly = TRUE),
            requireNamespace("tigris", quietly = TRUE),
            requireNamespace("cowplot", quietly = TRUE),
            requireNamespace("tibble", quietly = TRUE),
            requireNamespace("scales", quietly = TRUE),
            requireNamespace("grid", quietly = TRUE))
  
  aggregation_level <- match.arg(aggregation_level)
  minimap_region    <- match.arg(minimap_region)
  
  if (!is.numeric(label_threshold) || length(label_threshold) != 1L)
    stop("`label_threshold` must be a single numeric value.")
  if (!is.numeric(box_expand) || length(box_expand) != 1L || box_expand < 0)
    stop("`box_expand` must be a single nonnegative numeric value.")
  
  # Required columns for the datasets always available
  needed_county <- c("pm25_weighted","STATEFP","COUNTYFP","NAME")
  if (!all(needed_county %in% names(counties_out)))
    stop("counties_out must include: ", paste(needed_county, collapse=", "))
  
  needed_cs <- c("STATEFP","COUNTYFP","NAME")
  if (!all(needed_cs %in% names(counties_sf)))
    stop("counties_sf must include: ", paste(needed_cs, collapse=", "))
  
  # Level-specific requirements
  if (aggregation_level == "tract") {
    needed_tract <- c("pm25_weighted","STATEFP","COUNTYFP")
    if (!all(needed_tract %in% names(tracts_out)))
      stop("tracts_out must include: ", paste(needed_tract, collapse=", "))
  }
  if (aggregation_level == "grid") {
    if (is.null(cells)) stop("`cells` (sf) is required when aggregation_level='grid'.")
    if (!grid_fill_col %in% names(cells))
      stop("`cells` must contain column `", grid_fill_col, "`.")
  }
  if (aggregation_level == "town") {
    if (is.null(towns_exposed_sf))
      stop("`towns_exposed_sf` (sf) is required when aggregation_level='town'.")
    # Must have NAME and pm25_weighted for plotting + labels
    needed_town <- c("NAME","pm25_weighted")
    if (!all(needed_town %in% names(towns_exposed_sf)))
      stop("`towns_exposed_sf` must include: ", paste(needed_town, collapse=", "))
  }
  
  # --- State context selection ----------------------------------------------
  se_states <- c("VA","WV","MD","DC","DE","PA","NC","SC","GA","TN","KY","AL","MS","FL")
  wv_states <- c("VA","WV","MD","DC","DE","PA","NC","SC","OH","NJ","KY","TN")
  midsouth_states <- c("TN","MS","AR","KY","MO","AL") 
  
  states_raw <- tigris::states(cb = TRUE, year = 2024)
  
  states_context_sel <- switch(
    minimap_region,
    "se"       = dplyr::filter(states_raw, STUSPS %in% se_states),
    "wv"       = dplyr::filter(states_raw, STUSPS %in% wv_states),
    "midsouth" = dplyr::filter(states_raw, STUSPS %in% midsouth_states),  # <- new
    "us"       = states_raw
    ) |>
    sf::st_transform(target_crs) |>
    sf::st_make_valid()
  
  # --- Transform common layers ----------------------------------------------
  plant_t    <- sf::st_transform(plant,        target_crs)
  counties_t <- sf::st_transform(counties_out, target_crs)
  
  tracts_t   <- if (aggregation_level == "tract") sf::st_transform(tracts_out, target_crs) else NULL
  cells_t    <- if (aggregation_level == "grid")  sf::st_transform(cells,      target_crs) else NULL
  towns_t    <- if (aggregation_level == "town")  sf::st_transform(towns_exposed_sf, target_crs) else NULL
  
  # --- Determine "hot" keys / features and extent ----------------------------
  if (aggregation_level == "tract") {
    hot_keys <- tracts_out |>
      sf::st_drop_geometry() |>
      dplyr::filter(is.finite(pm25_weighted), pm25_weighted >= label_threshold) |>
      dplyr::distinct(STATEFP, COUNTYFP)
    
    counties_to_label <- counties_sf |>
      dplyr::semi_join(hot_keys, by = c("STATEFP","COUNTYFP")) |>
      sf::st_transform(target_crs) |>
      sf::st_make_valid()
    
    bb_src <- if (nrow(counties_to_label) > 0) sf::st_bbox(counties_to_label) else sf::st_bbox(counties_t)
    
  } else if (aggregation_level == "county") {
    hot_keys <- counties_out |>
      sf::st_drop_geometry() |>
      dplyr::filter(is.finite(pm25_weighted), pm25_weighted >= label_threshold) |>
      dplyr::distinct(STATEFP, COUNTYFP)
    
    counties_to_label <- counties_sf |>
      dplyr::semi_join(hot_keys, by = c("STATEFP","COUNTYFP")) |>
      sf::st_transform(target_crs) |>
      sf::st_make_valid()
    
    bb_src <- if (nrow(counties_to_label) > 0) sf::st_bbox(counties_to_label) else sf::st_bbox(counties_t)
    
  } else if (aggregation_level == "grid") {
    hot_cells <- dplyr::filter(cells_t,
                               is.finite(.data[[grid_fill_col]]),
                               .data[[grid_fill_col]] >= label_threshold)
    # counties for labels (optional, keep consistent with other modes)
    if (nrow(hot_cells) > 0) {
      hot_union <- sf::st_union(sf::st_make_valid(hot_cells))
      idx <- sf::st_intersects(sf::st_make_valid(counties_out),
                               sf::st_transform(hot_union, sf::st_crs(counties_out)),
                               sparse = TRUE)
      keep <- lengths(idx) > 0
      counties_to_label <- counties_sf |>
        dplyr::semi_join(
          counties_out[keep, ] |> sf::st_drop_geometry() |> dplyr::select(STATEFP, COUNTYFP),
          by = c("STATEFP","COUNTYFP")
        ) |>
        sf::st_transform(target_crs) |>
        sf::st_make_valid()
      bb_src <- sf::st_bbox(hot_cells)
    } else {
      counties_to_label <- counties_sf[0,] |> sf::st_transform(target_crs)
      bb_src <- sf::st_bbox(counties_t)
      warning("No grid cells ≥ label_threshold; extent defaults to all context counties.")
    }
    
  } else { # "town"
    towns_hot <- towns_t |>
      dplyr::filter(is.finite(pm25_weighted), pm25_weighted >= label_threshold)
    
    # For "town" mode we label towns, not counties
    counties_to_label <- NULL
    bb_src <- if (nrow(towns_hot) > 0) sf::st_bbox(towns_hot) else sf::st_bbox(towns_t)
  }
  
  # --- Expand bbox for view --------------------------------------------------
  dx <- bb_src$xmax - bb_src$xmin
  dy <- bb_src$ymax - bb_src$ymin
  xlim <- c(bb_src$xmin - box_expand * dx, bb_src$xmax + box_expand * dx)
  ylim <- c(bb_src$ymin - box_expand * dy, bb_src$ymax + box_expand * dy)
  
  # box_poly <- bb_src %>% sf::st_as_sfc() %>% sf::st_set_crs(target_crs) %>% sf::st_as_sf()
  
  # --- Label anchors ---------------------------------------------------------
  if (aggregation_level %in% c("tract","county","grid")) {
    county_labels <- if (!is.null(counties_to_label) && nrow(counties_to_label) > 0) {
      counties_to_label |>
        sf::st_point_on_surface() |>
        sf::st_coordinates() |> tibble::as_tibble() |>
        dplyr::bind_cols(counties_to_label |> sf::st_drop_geometry()) |>
        dplyr::transmute(NAME, X = X, Y = Y)
    } else {
      tibble::tibble(NAME = character(), X = numeric(), Y = numeric())
    }
  } else {
    town_labels <- if (exists("towns_hot") && nrow(towns_hot) > 0) {
      towns_hot |>
        sf::st_point_on_surface() |>
        sf::st_coordinates() |> tibble::as_tibble() |>
        dplyr::bind_cols(towns_hot |> sf::st_drop_geometry()) |>
        dplyr::transmute(NAME, X = X, Y = Y)
    } else {
      tibble::tibble(NAME = character(), X = numeric(), Y = numeric())
    }
  }
  
  # --- Fill layer & boundary layer by level ---------------------------------
  if (aggregation_level == "tract") {
    fill_layer <- ggplot2::geom_sf(
      data = dplyr::filter(tracts_t,
                           is.finite(pm25_weighted),
                           STATEFP %in% states_context_sel$STATEFP),
      ggplot2::aes(fill = pm25_weighted), color = NA
    )
    boundary_layer <- ggplot2::geom_sf(
      data = dplyr::filter(counties_t,
                           is.finite(pm25_weighted),
                           STATEFP %in% states_context_sel$STATEFP),
      fill = NA, color = "gray55", linewidth = 0.15
    )
    label_layer <- ggrepel::geom_label_repel(
      data = county_labels,
      ggplot2::aes(X, Y, label = NAME),
      size = 4,
      fill = scales::alpha("white", 0.6),
      color = "black", label.size = 0,
      label.padding = grid::unit(0.08, "lines"),
      box.padding   = 0.05, point.padding = 0.00,
      force = 0.5, force_pull = 1,
      max.iter = 500, max.time = 2,
      min.segment.length = 0, segment.size = 0.25, segment.alpha = 0.4,
      max.overlaps = Inf, seed = 123, inherit.aes = FALSE
    )
  } else if (aggregation_level == "county") {
    fill_layer <- ggplot2::geom_sf(
      data = dplyr::filter(counties_t,
                           is.finite(pm25_weighted),
                           STATEFP %in% states_context_sel$STATEFP),
      ggplot2::aes(fill = pm25_weighted),
      color = "gray55", linewidth = 0.15
    )
    boundary_layer <- NULL
    label_layer <- ggrepel::geom_label_repel(
      data = county_labels,
      ggplot2::aes(X, Y, label = NAME),
      size = 2.75, family = "Helvetica",
      fill = scales::alpha("white", 0.6),
      color = "black", label.size = 0,
      label.padding = grid::unit(0.08, "lines"),
      box.padding   = 0.05, point.padding = 0.00,
      force = 0.5, force_pull = 2,
      max.iter = 20, max.time = 0.5,
      min.segment.length = 0, segment.size = 0.25, segment.alpha = 0.5,
      max.overlaps = Inf, seed = 123, inherit.aes = FALSE
    )
  } else if (aggregation_level == "grid") {
    fill_layer <- ggplot2::geom_sf(
      data = cells_t,
      ggplot2::aes(fill = .data[[grid_fill_col]]),
      color = NA
    )
    boundary_layer <- ggplot2::geom_sf(
      data = dplyr::filter(counties_t,
                           STATEFP %in% states_context_sel$STATEFP),
      fill = NA, color = "gray55", linewidth = 0.15
    )
    label_layer <- ggrepel::geom_label_repel(
      data = county_labels,
      ggplot2::aes(X, Y, label = NAME),
      size = 2.75, family = "Helvetica",
      fill = scales::alpha("white", 0.6),
      color = "black", label.size = 0,
      label.padding = grid::unit(0.08, "lines"),
      box.padding   = 0.05, point.padding = 0.00,
      force = 0.5, force_pull = 2,
      max.iter = 20, max.time = 0.5,
      min.segment.length = 0, segment.size = 0.25, segment.alpha = 0.5,
      max.overlaps = Inf, seed = 123, inherit.aes = FALSE
    )
  } else { # "town"
    fill_layer <- ggplot2::geom_sf(
      data = towns_hot,
      ggplot2::aes(fill = pm25_weighted),
      color = "gray45", linewidth = 0.15
    )
    
    boundary_layer <- ggplot2::geom_sf(
      data = dplyr::filter(counties_t,
                           STATEFP %in% states_context_sel$STATEFP),
      fill = NA, color = "gray55", linewidth = 0.15
    )
    
    # Town labels: semi-transparent halo, minimal repulsion, stay near centroid
    label_layer <- ggrepel::geom_label_repel(
      data = town_labels,
      ggplot2::aes(X, Y, label = NAME),
      size = 4,                              # a bit larger for readability
      family = "Helvetica",
      fill = scales::alpha("white", 0.8),
      color = "black",
      label.size = 0,
      label.padding = grid::unit(0.15, "lines"),
      box.padding   = 0.2,                   # more space between labels
      point.padding = 0.25,                  # pushes labels away from centroid
      force         = 1.5,                   # stronger repel
      force_pull    = 0.5,                   # don't pull them too hard back to the point
      max.iter      = 50,
      max.time      = 1,
      min.segment.length = 0,
      segment.size  = 0.3,
      segment.alpha = 0.5,
      max.overlaps  = Inf,
      seed = 123,
      inherit.aes   = FALSE
    )
    
    # label_layer <- ggrepel::geom_label_repel(
    #   data = town_labels,
    #   ggplot2::aes(X, Y, label = NAME),
    #   size = 2.7,
    #   family = "Helvetica",
    #   fill = scales::alpha("white", 0.75),    # soft halo
    #   color = "black",
    #   label.size = 0,                         # remove border line
    #   label.padding = grid::unit(0.10, "lines"),
    #   box.padding   = 0.12,                   # light repel to avoid overlap
    #   point.padding = 0.05,                   # keeps label close to centroid
    #   force         = 0.5,                    # weak repel (keeps close)
    #   force_pull    = 2,                      # pulls label back toward town
    #   max.iter      = 30,
    #   max.time      = 0.75,
    #   min.segment.length = 0,
    #   segment.size  = 0.25,
    #   segment.alpha = 0.4,
    #   max.overlaps  = Inf,
    #   seed = 123,
    #   inherit.aes = FALSE
    # )
  }
  
  legend_title <- if (aggregation_level == "grid") {
    bquote(.(grid_fill_col)~"(µg/"*m^3*")")
  } else {
    expression(PM[2.5]~"(µg/"*m^3*")")
  }
  
  # --- Main map --------------------------------------------------------------
  main_map <-
    ggplot2::ggplot() +
    fill_layer +
    boundary_layer +
    # ggplot2::geom_sf(data = box_poly, fill = NA, color = "black", linewidth = 0.5) +
    ggplot2::geom_sf(data = states_context_sel, fill = NA, color = "black", linewidth = 0.7) +
    ggplot2::geom_sf(data = plant_t, color = "blue", size = 2) +
    label_layer +
    ggplot2::scale_fill_distiller(
      palette = "YlOrRd", direction = 1,
      name    = legend_title,
      guide   = ggplot2::guide_colorbar(
        barwidth = grid::unit(8, "cm"),
        barheight = grid::unit(0.5, "cm"),
        title.position = "top", title.hjust = 0.5
      )
    ) +
    ggplot2::coord_sf(xlim = xlim, ylim = ylim, expand = FALSE) +
    ggplot2::theme_minimal(base_size = 14) +
    ggplot2::theme(
      legend.position = "bottom",
      panel.grid = ggplot2::element_blank(),
      axis.text  = ggplot2::element_blank(),
      axis.ticks = ggplot2::element_blank(),
      axis.title = ggplot2::element_blank(),
      plot.margin = ggplot2::margin(5.5, 5.5, 5.5, 5.5)
    )
  
  # --- Minimap ---------------------------------------------------------------
  if (isTRUE(minimap_include)) {
    bbox_disp <- c(xmin = xlim[1], ymin = ylim[1], xmax = xlim[2], ymax = ylim[2])
    class(bbox_disp) <- "bbox"
    disp_poly <- bbox_disp %>% sf::st_as_sfc() %>% sf::st_set_crs(target_crs) %>% sf::st_as_sf()
    
    minimap <- ggplot2::ggplot() +
      ggplot2::geom_sf(data = states_context_sel, fill = "grey95", color = "grey60", linewidth = 0.25) +
      ggplot2::geom_sf(data = disp_poly, fill = NA, color = "black", linewidth = 0.6) +
      ggplot2::theme_void() +
      ggplot2::theme(
        plot.background = ggplot2::element_rect(fill = "white", color = "grey70", linewidth = 0.6),
        plot.margin = ggplot2::margin(2, 2, 2, 2)
      )
    
    final_plot <- cowplot::ggdraw(main_map) +
      cowplot::draw_plot(minimap, x = minimap_x, y = minimap_y,
                         width = minimap_width, height = minimap_height)
  } else {
    final_plot <- main_map
  }
  
  return(final_plot)
}