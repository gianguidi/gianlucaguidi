# -------------------------------------------------------------------------
# Title    : Post-process InMAP Results & Maps 
# Author   : Michael Cork (edits applied)
# Date     : 2025-10-26 (updated)
# Purpose  : Aggregate grid to tracts/counties/towns, compute population-
#            weighted PM2.5, and produce maps with consistent thresholds.
# -------------------------------------------------------------------------

# 0) SETUP ------------------------------------------------------------------
suppressPackageStartupMessages({
  library(sf)
  library(dplyr)
  library(readr)
  library(ggplot2)
  library(tigris)
  library(tidycensus)
  library(tidyr)
  library(ggrepel)
  library(scales)
  library(kableExtra)
})
options(tigris_use_cache = TRUE)

# Source plotting helpers (expects make_pm25_map_with_minimap())
source("scripts/plotting_functions.R")

# ---- Config ---------------------------------------------------------------
timestamp     <- "25_06_29"
identifier    <- "canady_cluster"
timestamp     <- "25_10_21"
identifier    <- "tucker_tons"

# Work on tucker
timestamp     <- "25_10_24"
identifier    <- "tucker"

# Using 
timestamp     <- "26_01_05"
identifier    <- "timberman"


## Work on SELC Fluvanna set
timestamp     <- "25_11_10"
identifier    <- "fluvanna"

## Work on vantage data center
timestamp     <- "26_01_23"
identifier    <- "vantage"

## Work on xAI data center 
timestamp     <- "26_01_20"
identifier    <- "xai"

# Mke out dir
out_dir       <- file.path("output", paste0(timestamp, "_", identifier))
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)


# Inputs/outputs
inmap_shp   <- file.path(out_dir, sprintf("inmap_results_%s_%s.shp", timestamp, identifier))
tracts_csv  <- file.path(out_dir, "tracts_with_pm25.csv")
counties_csv<- file.path(out_dir, "counties_with_pm25.csv")
plant_shp    <- file.path(out_dir, "powerplant.shp")

# Map CRS (equal-area for CONUS; meters)
target_crs <- 5070  # EPSG:5070 NAD83 / Conus Albers

# 1) LOAD DATA (project first!) --------------------------------------------
stopifnot(file.exists(inmap_shp))
grid_raw <- st_read(inmap_shp, quiet = TRUE)
grid     <- st_transform(grid_raw, target_crs) %>% st_make_valid()

# US Census geos
tracts_sf   <- tracts(cb = TRUE, year = 2024)   %>% st_transform(target_crs) %>% st_make_valid()
counties_sf <- counties(cb = TRUE, year = 2024) %>% st_transform(target_crs) %>% st_make_valid()

# Power plant point
stopifnot(file.exists(plant_shp))
plant <- st_read(plant_shp, quiet = TRUE) %>% st_transform(target_crs)

message("✔ Loaded grid (", nrow(grid), " cells), tracts, counties, states, and plant.")

# 2) PREP GRID TABLE --------------------------------------------------------
cells <- grid %>%
  mutate(
    cell_id   = row_number(),
    cell_area = as.numeric(st_area(geometry))  # m^2
  ) %>%
  select(cell_id, TotalPM25, TotalPop, cell_area, geometry)

# 3) POP-WEIGHTED AGGREGATION ----------------------------------------------
# Computes: pm25_weighted = sum(C_cell * Pop_alloc_cell) / sum(Pop_alloc_cell)
aggregate_pw <- function(polys_sf, id_col) {
  polys_sf <- st_make_valid(polys_sf)
  
  # intersection keeps attributes from both
  overlap <- suppressWarnings(
    st_intersection(
      polys_sf %>% select(!!sym(id_col), STATEFP, COUNTYFP, everything()),
      cells
    )
  )
  
  overlap <- overlap %>%
    mutate(
      overlap_area = as.numeric(st_area(geometry)),
      area_frac    = pmax(pmin(overlap_area / cell_area, 1), 0),
      pop_alloc    = TotalPop  * area_frac,
      pm_pop       = TotalPM25 * pop_alloc
    )
  
  summary_tbl <- overlap %>%
    st_drop_geometry() %>%
    group_by(!!sym(id_col)) %>%
    summarize(
      total_pop     = sum(pop_alloc, na.rm = TRUE),
      total_pm_pop  = sum(pm_pop,   na.rm = TRUE),
      pm25_weighted = if_else(total_pop > 0, total_pm_pop / total_pop, NA_real_),
      .groups = "drop"
    )
  
  polys_sf %>% left_join(summary_tbl, by = id_col)
}

# Outputs
tracts_out   <- aggregate_pw(tracts_sf,  "GEOID")
counties_out <- aggregate_pw(counties_sf, "GEOID")

# Save CSVs
write_csv(tracts_out %>% st_drop_geometry(),  tracts_csv)
write_csv(counties_out %>% st_drop_geometry(), counties_csv)
message("✔ Wrote tract/county CSVs to ", out_dir)

# 4) OPTIONAL: Write shapefiles to share -----------------------------------
thr_show <- 0.001
st_write(tracts_out   %>% filter(pm25_weighted > thr_show),
         dsn = file.path(out_dir, "tracts_out.shp"),   delete_dsn = TRUE, quiet = TRUE)
st_write(counties_out %>% filter(pm25_weighted > thr_show),
         dsn = file.path(out_dir, "counties_out.shp"), delete_dsn = TRUE, quiet = TRUE)
message("✔ Wrote shapefiles (tracts_out.shp, counties_out.shp)")

# 5) Make plots  -----------------------------------------------------------

# Make plots of census tracts (include normal, and zoomed in plot)
tract_plot <- make_pm25_map_with_minimap(
  tracts_out   = tracts_out,
  counties_out = counties_out,
  counties_sf  = counties_sf,
  plant        = plant,
  target_crs   = 5070,
  label_threshold = 0.005,
  box_expand   = 0.001,
  minimap_region  = "wv",
  minimap_x = 0.815,
  minimap_y = -0.01,
  aggregation_level = "tract",
  minimap_include = TRUE)

tract_plot
ggsave(filename = file.path(out_dir, "tract_plot.png"),
       plot = tract_plot, width = 9, height = 7, dpi = 600)

# For Sterling use these width/height measurements
ggsave(filename = file.path(out_dir, "tract_plot.png"),
       plot = tract_plot, width = 8, height = 9, dpi = 600)
# ggsave(filename = file.path(out_dir, "tract_plot.png"),
#        plot = tract_plot, width = 6, height = 7, dpi = 600)

# now working on xAI
# Make plots of census tracts (include normal, and zoomed in plot)
tract_plot <- make_pm25_map_with_minimap(
  tracts_out   = tracts_out,
  counties_out = counties_out,
  counties_sf  = counties_sf,
  plant        = plant,
  target_crs   = 5070,
  label_threshold = 0.005,
  box_expand   = 0.001,
  minimap_region  = "midsouth",
  minimap_x = 0.81,
  minimap_y = -0.01,
  aggregation_level = "tract",
  minimap_include = TRUE)

# For xAI use these width/height measurements
ggsave(filename = file.path(out_dir, "tract_plot.png"),
       plot = tract_plot, width = 8, height = 10, dpi = 600)


tract_zoom <- make_pm25_map_with_minimap(
  tracts_out   = tracts_out,
  counties_out = counties_out,
  counties_sf  = counties_sf,
  plant        = plant,
  target_crs   = 5070,
  label_threshold = 0.01,
  box_expand   = 0.01,
  minimap_x = 0.815,
  minimap_y = -0.01,
  minimap_region  = "wv",
  aggregation_level = "tract",
  minimap_include = TRUE)

tract_zoom

# For Fluvanna use these width/height measurements
ggsave(filename = file.path(out_dir, "tract_zoom.png"),
       plot = tract_zoom, width = 8, height = 8.75, dpi = 600)


# Here is what I used for tucker
ggsave(filename = file.path(out_dir, "tract_zoom2.png"),
       plot = tract_zoom, width = 8.5, height = 7.5, dpi = 600)

# This is for Sterling
ggsave(filename = file.path(out_dir, "tract_plot_zoom.png"),
       plot = tract_zoom, width = 8, height = 10, dpi = 600)

# Working on xAI
tract_zoom <- make_pm25_map_with_minimap(
  tracts_out   = tracts_out,
  counties_out = counties_out,
  counties_sf  = counties_sf,
  plant        = plant,
  target_crs   = 5070,
  label_threshold = 0.01,
  box_expand   = 0.01,
  minimap_x = 0.815,
  minimap_y = -0.01,
  minimap_region  = "midsouth",
  aggregation_level = "tract",
  minimap_include = TRUE)

# This is for Sterling
ggsave(filename = file.path(out_dir, "tract_plot_zoom.png"),
       plot = tract_zoom, width = 8, height = 10, dpi = 600)



# Now make a plot of the county, not census tracts 
county_plot <- make_pm25_map_with_minimap(
  tracts_out   = tracts_out,
  counties_out = counties_out,
  counties_sf  = counties_sf,
  plant        = plant,
  target_crs   = 5070,
  label_threshold = 0.005,
  box_expand   = 0.01,
  minimap_x = 0.825,
  minimap_y = 0,
  minimap_region  = "wv",
  aggregation_level = "county",
  minimap_include = TRUE)

county_plot
ggsave(filename = file.path(out_dir, "county_plot.png"),
       plot = county_plot, width = 8, height = 9, dpi = 600)

# Sterling presets 


# Make a table of top counties
# 1) Max tract-level ΔPM2.5 within each county
county_max_tract <- tracts_out %>%
  st_drop_geometry() %>%
  group_by(STATEFP, COUNTYFP) %>%
  summarize(
    max_tract_pm = suppressWarnings(max(pm25_weighted, na.rm = TRUE)),
    .groups = "drop"
  )

# 2) Join to county_impact (which already has avg_increment)
#    and rank by highest population-weighted county average ΔPM2.5
top_counties_tbl <- counties_out %>%
  left_join(county_max_tract, by = c("STATEFP","COUNTYFP")) %>%
  filter(is.finite(pm25_weighted)) %>%
  arrange(desc(pm25_weighted)) %>%
  slice_head(n = 5) %>%
  transmute(
    State      = STATE_NAME,
    County     = NAMELSAD,
    `Population` = scales::comma(round(total_pop)),
    `Avg ΔPM2.5 (µg/m³)` = signif(pm25_weighted, 3),
    `Max tract ΔPM2.5 (µg/m³)` = signif(max_tract_pm, 3)
  )

# Save + display
readr::write_csv(top_counties_tbl, file.path(out_dir, "top_counties_pm25.csv"))

top_counties_tbl %>%
  kbl(caption = "Top 5 Counties by Population-Weighted Average ΔPM2.5 (with County Max Tract ΔPM2.5)") %>%
  kable_styling(full_width = FALSE, position = "center", font_size = 12)


# Now make a plot of the county, not census tracts 
grid_plot <- make_pm25_map_with_minimap(
  tracts_out, counties_out, counties_sf, plant, 5070,
  label_threshold = 0.005,
  box_expand = 0.01,
  aggregation_level = "grid",
  minimap_region = "midsouth",
  minimap_include = TRUE,
  cells = cells,
  grid_fill_col = "TotalPM25"
)
grid_plot
ggsave(filename = file.path(out_dir, "grid_plot.png"),
       plot = grid_plot, width = 10, height = 8, dpi = 600)

# 8) TOWNS: POP-WEIGHTED AVERAGE VIA INTERSECTION --------------------------
state_list <- c("WV", "VA", "MD")
state_list <- c("VA","WV","MD","DC","DE","PA","NC","SC","OH","NJ","KY","TN")
state_list <- c("TN","MS","AR","KY","MO","AL") 
pm_thr <- 0.005

# --- State lookup (for adding STUSPS) ---------------------------------------
state_lookup <- tigris::states(cb = TRUE, year = 2024) |>
  st_drop_geometry() |>
  select(STATEFP, STUSPS)

# --- Pull towns (places) -----------------------------------------------------
towns_places <- tigris::places(state = state_list, cb = FALSE, year = 2024) |>
  select(GEOID, STATEFP, NAME, NAMELSAD) |>
  left_join(state_lookup, by = "STATEFP") |>
  st_transform(target_crs) |>
  st_make_valid()
suppressWarnings({
  overlap <- st_intersection(cells, towns_places)
})
overlap <- overlap |>
  mutate(
    overlap_area = as.numeric(st_area(geometry)),
    area_frac    = pmax(pmin(overlap_area / cell_area, 1), 0),
    pop_alloc    = TotalPop  * area_frac,
    pm_pop       = TotalPM25 * pop_alloc
  )

# --- Town-level pop-weighted PM2.5 ------------------------------------------
town_pm_weighted <- overlap |>
  st_drop_geometry() |>
  group_by(GEOID, STATEFP, STUSPS, NAME) |>
  summarize(
    total_pop     = sum(pop_alloc, na.rm = TRUE),
    total_pm_pop  = sum(pm_pop,   na.rm = TRUE),
    pm25_weighted = if_else(total_pop > 0, total_pm_pop / total_pop, NA_real_),
    max_cell_pm   = suppressWarnings(max(TotalPM25, na.rm = TRUE)),
    n_overlaps    = n(),
    .groups = "drop"
  )
# --- ACS 2022 place population ----------------------------------------------
# (uses total population B01003_001)
place_pop_acs <- tidycensus::get_acs(
  geography = "place",
  state     = state_list,
  variables = c(total_pop = "B01003_001"),
  year      = 2022, survey = "acs5",
  geometry  = FALSE, output = "wide"
) |>
  transmute(GEOID = as.character(GEOID),
            acs_place_pop = as.numeric(total_popE))

# --- Join ACS pop; drop towns w/o ACS match ---------------------------------
town_pm_cal <- town_pm_weighted |>
  mutate(GEOID = as.character(GEOID)) |>
  left_join(place_pop_acs, by = "GEOID") |>
  mutate(
    acs_match     = !is.na(acs_place_pop),
    # if you ever want a fallback, replace next line with if_else(acs_match, acs_place_pop, total_pop)
    total_pop_adj = acs_place_pop
  )

# --- Join back to geometry & keep finite PM and ACS matches ------------------
towns_exposed_sf <- towns_places |>
  left_join(town_pm_cal, by = c("GEOID","STATEFP","STUSPS","NAME")) |>
  filter(is.finite(pm25_weighted), acs_match, !is.na(total_pop_adj), total_pop_adj > 0)

# --- Top towns table (ACS-matched only) -------------------------------------
top_towns <- towns_exposed_sf |>
  filter(pm25_weighted >= pm_thr) |>
  arrange(desc(pm25_weighted)) |>
  st_drop_geometry() |>
  transmute(
    Town                   = NAME,
    State                  = STUSPS,
    `Population`= total_pop_adj,
    `PM2.5 (µg/m³)`        = pm25_weighted,
    `Max cell PM2.5`       = max_cell_pm,
    `Cells overlapped`     = n_overlaps
  ) |>
  mutate(
    `PM2.5 (µg/m³)`         = signif(`PM2.5 (µg/m³)`, 3),
    `Max cell PM2.5`        = signif(`Max cell PM2.5`, 3),
    `Population` = comma(round(as.numeric(`Population`)))
  )

# Preview the top 20 in a nicely formatted table
top_towns[, 1:4] |>
  slice_head(n = 20) |>
  kbl(caption = "Top Towns by PM2.5 Exposure") |>
  kable_styling(full_width = FALSE, position = "center", font_size = 12)

top_towns[, 1:4] |>
  slice_head(n = 10) |>
  readr::write_csv(file.path(out_dir, "towns.csv"))

# Now make plot
town_plot <- make_pm25_map_with_minimap(
  tracts_out, counties_out, counties_sf, plant, 5070,
  label_threshold = 0.01,
  box_expand = 0.005,
  aggregation_level = "town",
  minimap_region = "midsouth",
  minimap_x = 0.81,
  minimap_y = 0,
  minimap_include = TRUE,
  towns_exposed_sf = towns_exposed_sf   # <- your ACS-matched towns sf
)
town_plot
ggsave(filename = file.path(out_dir, "town_plot.png"),
       plot = town_plot, width = , height = 7, dpi = 600)

# For Fluvanna 
ggsave(filename = file.path(out_dir, "town_plot.png"),
       plot = town_plot, width = 15, height = 12.5, dpi = 600)

# for sterling
ggsave(filename = file.path(out_dir, "town_plot.png"),
       plot = town_plot, width = 11, height = 12.3, dpi = 600)

# for xai
ggsave(filename = file.path(out_dir, "town_plot.png"),
       plot = town_plot, width = 11, height = 12.3, dpi = 600)


### Look at top 10 counties
# Preview the top 20 in a nicely formatted table
counties_out |>
  arrange(-pm25_weighted) %>%
  st_drop_geometry() %>%
  mutate(PM2.5 = round(pm25_weighted, 3)) %>% 
  select(NAME, PM2.5) %>% 
  slice_head(n = 10) |>
  kbl(caption = "Top Counties by Population-Weighted PM2.5 Exposure") |>
  kable_styling(full_width = FALSE, position = "center", font_size = 12)



# 9) COUNTY IMPACT ANALYSIS: Where is the exposure burden concentrated? ------------------------
# --------------------------------------------------------------------
# Goal: Convert pollution increments into *population-weighted exposure*.
# This quantifies how much pollution people are actually breathing,
# allowing us to identify which counties bear the greatest public-health burden.

# Step 1: Multiply PM increment by population to get *person-µg exposure*.
# This measures *how many people are breathing how much pollution* in each tract.
tracts_demographic <- tracts_out %>%
  mutate(
    # pop_exposure units are (µg/m³ * people) = person-µg/m³
    pop_exposure = pm25_weighted * total_pop
  )

# Step 2: Aggregate exposure burden and population up to the county level.
# Also compute each county’s *average exposure per person* (population-weighted mean).
county_impact <- tracts_demographic %>%
  group_by(STATEFP, COUNTYFP) %>%
  summarize(
    total_pop_exposure = sum(pop_exposure, na.rm = TRUE),   # total burden
    population         = sum(total_pop,    na.rm = TRUE),   # total people in county
    avg_increment      = weighted.mean(pm25_weighted, w = total_pop, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  
  # Join county names
  left_join(
    counties_sf %>% st_drop_geometry() %>% 
      select(STATEFP, COUNTYFP, county = NAMELSAD, state = STATE_NAME),
    by = c("STATEFP", "COUNTYFP")
  ) %>%
  
  # Step 3: Compute *share of total burden* across all counties in the impact region.
  mutate(
    share_total_exposure = total_pop_exposure / sum(total_pop_exposure, na.rm = TRUE)
  ) %>%
  arrange(desc(share_total_exposure))   # rank counties from highest to lowest burden


# ---- Save COUNTY-LEVEL burden results --------------------------------------

# ---- Pull ACS 2022 county population --------------------------------------
acs_county_pop <- tidycensus::get_acs(
  geography = "county",
  variables = c(total_pop = "B01001_001"),
  year = 2022,
  survey = "acs5",
  geometry = FALSE,
  output = "wide"
) %>%
  transmute(
    STATEFP = substr(GEOID, 1, 2),
    COUNTYFP = substr(GEOID, 3, 5),
    acs_population = as.numeric(total_popE)
  )

county_impact <- county_impact %>%
  left_join(acs_county_pop, by = c("STATEFP", "COUNTYFP"))

county_impact_export <- county_impact %>%
  transmute(
    county,
    state,
    population = round(acs_population, -2),   # ACS population, nearest 100
    share_total_exposure = round(100 * share_total_exposure, 2),
    avg_increment       = round(avg_increment, 5)
  ) %>%
  st_drop_geometry()

# These can be pasted into the reports themselves 
county_impact_export %>%
  slice_head(n = 10) |>
  kbl(caption = "Top Counties by Population-Weighted PM2.5 Exposure") |>
  kable_styling(full_width = FALSE, position = "center", font_size = 12)


# This shows top counties with population and state
county_impact_export %>%
  arrange(-avg_increment) %>%
  select(-share_total_exposure) %>%
  slice_head(n = 10) |>
  kbl(caption = "Top Counties by Population-Weighted PM2.5 Exposure") |>
  kable_styling(full_width = FALSE, position = "center", font_size = 12)

readr::write_csv(county_impact_export, file.path(out_dir, "county_burden_ranked.csv"))
message("✔ Wrote county_burden_ranked.csv (counties ranked by total exposure burden)")

# ---- Summarize at STATE level ----------------------------------------------
# This shows *which states* are carrying the most total burden,
# even if they do NOT all have the same number of impacted counties.
state_burden <- county_impact %>%
  group_by(state) %>%
  summarize(
    state_pop           = sum(population, na.rm = TRUE),
    state_total_exp     = sum(total_pop_exposure, na.rm = TRUE),
    # average exposure per person in the state
    avg_state_increment = weighted.mean(avg_increment, w = population, na.rm = TRUE),
    # share of total multi-state exposure burden
    state_share_total   = state_total_exp / sum(county_impact$total_pop_exposure),
    .groups = "drop"
  ) %>%
  arrange(desc(state_share_total))

# Format & save
state_burden_export <- state_burden %>%
  transmute(
    state,
    state_pop,
    avg_state_increment = round(avg_state_increment, 5),
    state_total_exp = round(state_total_exp, 1),
    state_share_total = round(100 * state_share_total, 2)
  ) %>% st_drop_geometry()

readr::write_csv(state_burden_export, file.path(out_dir, "state_burden_summary.csv"))
message("✔ Wrote state_burden_summary.csv (state share of total exposure burden)")

message("✅ Done.")
