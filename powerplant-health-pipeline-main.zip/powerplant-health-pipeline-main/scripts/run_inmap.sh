#!/bin/bash
#SBATCH --partition=shared
#SBATCH --qos=normal
#SBATCH --account=dominici_lab
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --mem-per-cpu=70G        # 70 GB per task (this is for finer)
#SBATCH --time=1-00:00:00        # 1 days
#SBATCH --job-name=inmap_${1}_${3}
#SBATCH --output=Logs/slurm-%x-%j.out
#SBATCH --error=Logs/slurm-%x-%j.err
#SBATCH --mail-user=mcork@g.harvard.edu
#SBATCH --mail-type=END,FAIL

# ------------------------------------------
# 1) Parse positional arguments
# ------------------------------------------
identifier="$1"   # e.g. "canady"
timestamp="$2"    # e.g. "25_06_27"
scenario="$3"     # "coarse" or "standard"

if [[ -z "$identifier" || -z "$timestamp" || -z "$scenario" ]]; then
  echo "Usage: sbatch run_inmap.sh <identifier> <timestamp> <scenario>"
  exit 1
fi

# ------------------------------------------
# 2) Set paths & Singularity image
# ------------------------------------------
project_dir="${HOME}/nsaph_projects/powerplant-health-pipeline"
sh_script="${project_dir}/scripts/1_run_inmap.R"
my_packages="${HOME}/R/ifxrstudio/RELEASE_3_16"
rstudio_singularity_image="/n/singularity_images/informatics/ifxrstudio/ifxrstudio:RELEASE_3_16.sif"

# ------------------------------------------
# 3) Change to project directory
# ------------------------------------------
cd "${project_dir}" || { echo "Error: Project directory not found"; exit 1; }
mkdir -p Logs

# ------------------------------------------
# 4) Run the R driver inside Singularity
# ------------------------------------------
singularity exec --cleanenv \
  --bind "${project_dir}:${project_dir}" \
  --env R_LIBS_USER="${my_packages}" \
  "${rstudio_singularity_image}" \
  Rscript "${sh_script}" "$identifier" "$timestamp" "$scenario"

exit_code=$?
if [ $exit_code -ne 0 ]; then
  echo "❌ InMAP workflow failed (exit code $exit_code)"
  exit $exit_code
else
  echo "✅ InMAP workflow completed successfully"
  exit 0
fi