# Script to run through inmap on the cluster

# --- parse command-line args --------------------------------------
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 3) {
  stop("Usage: Rscript 1_run_inmap.R <identifier> <timestamp> <scenario>")
}
identifier <- args[1]
timestamp  <- args[2]
scenario   <- args[3]  # "standard" or "finer"

# --- load libraries -----------------------------------------------
library(readr)
library(dplyr)
library(sf)
library(units)
library(blogdown)

# --- set up folders & paths --------------------------------------
output_folder <- file.path("output", paste0(timestamp, "_", identifier))
dir.create(output_folder, recursive = TRUE, showWarnings = FALSE)

shp_path <- file.path(output_folder, "powerplant.shp")

# --- read & patch config -----------------------------------------
config_in <- "config/config_powerplant-health-pipeline.toml"
config    <- read_toml(config_in)

config$EmissionsShapefiles <- list(shp_path)
config$OutputFile          <- file.path(output_folder,
                                        sprintf("inmap_results_%s_%s.shp", timestamp, identifier))
config$LogFile             <- file.path(output_folder,
                                        sprintf("inmap_log_results_%s_%s.log", timestamp, identifier))
config$EmissionUnits       <- "kg/year"

config$InMAPData           <- sub("^insert_data_path", "InMap", config$InMAPData)
config$VariableGridData    <- sub("^insert_data_path", "InMap", config$VariableGridData)
config$VarGrid$CensusFile  <- sub("^insert_data_path", "InMap", config$VarGrid$CensusFile)
config$VarGrid$MortalityRateFile <- sub("^insert_data_path", "InMap", config$VarGrid$MortalityRateFile)

# --- scenario-specific grid params -------------------------------
grid_par <- list(
  # === standard: original settings (finest ≈ 9 km) ===
  standard = list(
    dx = 288000L, # outer cell (meters)
    nests = c(2L,2L,2L,2L,2L), # 5 halvings -> 288000 / 2^5 = 9000 m finest (~9 km)
    layers = 8L,
    pop_thr = 40000, # refine if cell contains > 40k people
    pop_dens = 0.0055, # ~5,500 persons/km^2
    pop_conc = 5e-11
  ),
  
  
  # === finer: target ~1-3 km in dense areas (implemented as ~2.25 km finest) ===
  finer = list(
    dx = 288000L,
    nests = rep(2L, 7L), # 7 halvings -> 288000 / 2^7 = 2250 m finest (~2.25 km)
    layers = 8L,
    pop_thr = 15000, # trigger refinement where cells contain >15k people
    pop_dens = 0.0035, # ~3,500 persons/km^2
    pop_conc = 5e-11
  )
)

if (!scenario %in% names(grid_par)) {
  stop("Scenario '", scenario, "' not recognized. Available: ", paste(names(grid_par), collapse = ", "))
}


gp <- grid_par[[scenario]]


# diagnostic messages (outer cell and computed finest cell)
finest_m <- gp$dx / (2^length(gp$nests))
finest_km <- finest_m / 1000
message(sprintf("🔧 Scenario = %s (outer cell = %.0f km; finest cell ≈ %.3f km)",
                scenario, gp$dx / 1000, finest_km))


# send the grid to a unique file in the output folder
config$VariableGridData <- file.path(
  output_folder,
  paste0("Grid_", scenario, ".gob")
)


# write out the TOML
config_out <- file.path(output_folder, "config.toml")
write_toml(config, config_out)
message("✅ Wrote ", config_out)

# --- run InMAP ----------------------------------------------------
inmap_exec <- file.path(
  normalizePath("~/nsaph_projects/powerplant-health-pipeline/InMap"),
  ifelse(.Platform$OS.type=="unix" && grepl("darwin", R.version$os),
         "inmap-v1.9.6-darwin-arm64",
         "inmap-v1.9.6-linux-amd64")
)

if (!file.exists(inmap_exec)) {
  stop("❌ InMAP executable not found at: ", inmap_exec)
}

message("🚀 Running InMAP...")
res2 <- system2(inmap_exec,
                args = c("run", "steady", paste0("--config=", config_out)),
                stdout = TRUE, stderr = TRUE)
message(paste(res2, collapse = "\n"))
message("🎉 InMAP run complete!")