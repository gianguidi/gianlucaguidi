# ===================================================================
# InMAP Point-Source Shapefile Builder (single plant, catalog-driven)
# ===================================================================
# HOW TO USE:
# 1) Edit/extend the PLANT CATALOG (one row per plant).
# 2) Set SELECT_PLANT_ID to the plant you want to run.
# 3) Run the script. It writes an InMAP-ready shapefile to /output/.
#
# SCENARIOS (per plant via 'method'):
# - "EF"      : compute emissions from EF (kg/MWh) × capacity × uptime (capacity factor).
# - "PERMIT"  : use permit tons/year (tpy) → converted to kg/yr.
#
# STACK PARAMS (elevated release):
# - Defaults are defensible for NGCC:
#     height = 65 m  (Good Engineering Practice / GEP credit floor)
#     diam   = 5 m
#     temp   = 416 K 
#     velocity = 23 m/s
# - Optional per-plant overrides: height_m, diam_m, temp_K, vel_ms.
#
# (Citations you may keep in your README/Methods)
# - GEP stack height guidance (EPA SCRAM):
#   https://www.epa.gov/scram/clean-air-act-permit-modeling-guidance
# - Typical utility stack medians (EPA RSEI Appendix E: stacks):
#   https://www.epa.gov/system/files/documents/2024-03/technical-appendix-e-stacks-v2.3.12.pdf
# ===================================================================

# ---- Libraries ----
library(dplyr)
library(tibble)
library(sf)
library(ggplot2)

# ---- Choose which plant to run this time ----
SELECT_PLANT_ID <- "tucker"  # "tucker" | "fluvanna" | "canadys" | add more rows in the catalog

# SELECT_PLANT_ID <- "fluvanna"
# SELECT_PLANT_ID <- "timberman"
SELECT_PLANT_ID <- "xai"
# SELECT_PLANT_ID <- "vantage"

# ---- Global defaults ----

# Default EF set (kg per MWh) used if method == "EF" and no plant-specific EF overrides are given
EF_DEFAULT <- list(
  PM25 = 0.0128936,  # kg/MWh (primary PM2.5)
  NOx  = 0.0149,     # kg/MWh (as NO2)
  SO2  = 0.0018,     # kg/MWh
  VOC  = 0.0000,     # kg/MWh (often small for NGCC with oxidation catalyst)
  CO2  = 375         # kg/MWh (not used by InMAP; kept for completeness)
)

# Emission factors from Greensville (original units lb/MWh) → convert to kg/MWh
LBS_TO_KG <- 0.45359237
EF_GREEN_LB <- list(
  PM25 = 0.03305216,          # lb/MWh (primary PM2.5; Greensville 2019-2021 avg)
  NOx  = 0.033,               # lb/MWh (Greensville 2023)
  SO2  = 0.004,               # lb/MWh (Greensville 2023)
  VOC  = 0.01721722046755,    # lb/MWh (VA 2021 state-level)
  NH3  = 0.0190432310358548   # lb/MWh (Greensville 2021)
)
EF_GREEN <- lapply(EF_GREEN_LB, function(x) x * LBS_TO_KG)  # kg/MWh

# Greensville-based capacity factor (average over 2019–2021)
# (E.g., uptime = generation / (nameplate * hours/year), averaged across years)
UPTIME_GV <- (
  11513187 / (1773.3 * 8760) +
    10675865 / (1773.3 * 8760) +
    9859878 / (1773.3 * 8760)
) / 3

UPTIME_DEFAULT <- 0.60                  # used if plant 'uptime' is NA and method == "EF"
TARGET_CRS     <- "ESRI:102003"         # common Albers projection used by InMAP builds

# Stack defaults (elevated release) — defensible NGCC-ish + GEP height
STACK_HEIGHT_M_DEFAULT <- 65
STACK_DIAM_M_DEFAULT   <- 5
STACK_TEMP_K_DEFAULT   <- 416
STACK_VEL_MS_DEFAULT   <- 23

# ---- Plant Catalog --------------------------------------------------
# Columns:
# - plant_id (key), plant_name, state (2-letter), lat, lon
# - method ("EF" or "PERMIT")
# - EF path:  capacity_mw, uptime (0–1; if NA → UPTIME_DEFAULT)
#             EF_PM25_kg_MWh, EF_NOx_kg_MWh, EF_SO2_kg_MWh, EF_VOC_kg_MWh, EF_NH3_kg_MWh (NA → EF_DEFAULT)
# - PERMIT path: tpy_PM25, tpy_NOx, tpy_SO2, tpy_VOC  (short tons/year)
# - Optional stack overrides: height_m, diam_m, temp_K, vel_ms  (NA → defaults above)
plants_catalog <- tribble(
  ~plant_id, ~plant_name,              ~state, ~lat,        ~lon,         ~method, ~capacity_mw, ~uptime,    ~EF_PM25_kg_MWh,      ~EF_NOx_kg_MWh,     ~EF_SO2_kg_MWh,     ~EF_VOC_kg_MWh,     ~EF_NH3_kg_MWh, ~tpy_PM25, ~tpy_NOx, ~tpy_SO2, ~tpy_VOC, ~height_m, ~diam_m, ~temp_K, ~vel_ms,
  "tucker",  "Tucker County (WV)",     "WV",   39.15364,   -79.46641,    "PERMIT",        NA,        NA,                 NA,                   NA,                 NA,                 NA,                 NA,        71.44,     99.25,    58.89,    43.84,       NA,       NA,     NA,     NA,
  "timberman",  "Tiberman Ridge (WV)",     "WV", 39.19300, -79.36864,    "PERMIT",        NA,        NA,                 NA,                   NA,                 NA,                 NA,                 NA,        71.44,     99.25,    58.89,    43.84,       NA,       NA,     NA,     NA,
  # Fluvanna: use Greensville-derived EF (kg/MWh) + Greensville uptime
  "fluvanna","Expedition NGCC (VA)",   "VA",   37.8663472, -78.3802683,  "EF",         1540,   UPTIME_GV,  EF_GREEN$PM25,        EF_GREEN$NOx,      EF_GREEN$SO2,      EF_GREEN$VOC,      EF_GREEN$NH3,         NA,        NA,       NA,       NA,       NA,       NA,     NA,     NA,
  "canadys", "Canadys NGCC (SC)",      "SC",   33.0643951, -80.6210316,  "EF",         2200,       0.60,        0.0128936,            0.0149,            0.0018,            0.0000,            0.0000,         NA,        NA,       NA,       NA,       NA,       NA,     NA,     NA,
  # Vantage (Sterling, VA) - facility-level PERMIT entry (all units combined)
  # Stack height set to 50 ft => 15.24 m (height_m overrides default)
  # Leave lat/lon as NA for now if you want to fill in exact coordinates later.
  "vantage", "Vantage Data Center (Sterling, VA)", "VA", 38.998544, -77.428488, "PERMIT",
  NA, NA, NA, NA, NA, NA, NA,
  56.51, 95.00, 19.21, 42.87,   # tpy_PM25, tpy_NOx, tpy_SO2, tpy_VOC (short tons/yr)
  15.24, 2.74, 686, 20.7,
  # xAI: use permit coordinates and the PERMIT emissions you requested
  "xai", "xAI Facility", "MS", 34.984353, -90.040228, "PERMIT", NA, NA, NA, NA, NA, NA, NA, 19.56, 423.39, 156.53, 417.40, 15.24, 2.74, 766.48, 21.47
)

# Helper functions
tpy_to_kgyr <- function(tpy) ifelse(is.na(tpy), 0, tpy * 907.185)

# Include NH3 in EF path so we can model secondary PM precursors downstream
ef_to_kgyr <- function(capacity_mw, uptime, ef_pm25, ef_nox, ef_so2, ef_voc, ef_nh3 = 0, ef_co2 = NA_real_) {
  mwh <- capacity_mw * 8760 * uptime
  list(
    PM2_5 = mwh * ef_pm25,
    NOx   = mwh * ef_nox,
    SOx   = mwh * ef_so2,
    VOC   = mwh * ef_voc,
    NH3   = mwh * ef_nh3
  )
}


# ---- Select the plant row ----
plant <- plants_catalog %>% filter(plant_id == SELECT_PLANT_ID)
if (nrow(plant) != 1) stop("SELECT_PLANT_ID not found or not unique in plants_catalog.")

method <- plant$method[[1]]

# ---- Compute emissions (kg/yr) for THIS plant ----
if (method == "EF") {
  capacity_mw <- as.numeric(plant$capacity_mw)
  if (is.na(capacity_mw)) stop("EF method requires 'capacity_mw' in catalog.")
  uptime      <- ifelse(is.na(plant$uptime), UPTIME_DEFAULT, as.numeric(plant$uptime))
  
  # EF overrides if present; otherwise use EF_DEFAULT
  ef_pm25 <- ifelse(is.na(plant$EF_PM25_kg_MWh), EF_DEFAULT$PM25, plant$EF_PM25_kg_MWh)
  ef_nox  <- ifelse(is.na(plant$EF_NOx_kg_MWh),  EF_DEFAULT$NOx,  plant$EF_NOx_kg_MWh)
  ef_so2  <- ifelse(is.na(plant$EF_SO2_kg_MWh),  EF_DEFAULT$SO2,  plant$EF_SO2_kg_MWh)
  ef_voc  <- ifelse(is.na(plant$EF_VOC_kg_MWh),  EF_DEFAULT$VOC,  plant$EF_VOC_kg_MWh)
  ef_nh3  <- ifelse(is.na(plant$EF_NH3_kg_MWh),  EF_DEFAULT$NH3,  plant$EF_NH3_kg_MWh)
  
  em <- ef_to_kgyr(capacity_mw, uptime, ef_pm25, ef_nox, ef_so2, ef_voc, ef_nh3)
  
  kg_PM25 <- em$PM2_5
  kg_NOx  <- em$NOx
  kg_SOx  <- em$SOx
  kg_VOC  <- em$VOC
  kg_NH3  <- em$NH3
  
} else if (method == "PERMIT") {
  
  kg_PM25 <- tpy_to_kgyr(as.numeric(plant$tpy_PM25))
  kg_NOx  <- tpy_to_kgyr(as.numeric(plant$tpy_NOx))
  kg_SOx  <- tpy_to_kgyr(as.numeric(plant$tpy_SO2))
  kg_VOC  <- tpy_to_kgyr(as.numeric(plant$tpy_VOC))
  
  # NH3 (kg/yr): default 0 unless we have a facility-specific derivation.
  # For xAI/MZX: derive facility-wide NH3 tpy from draft permit per-turbine limits × turbine counts:
  # AA (PGM-130): 5.18 tpy × 17
  # AB (Titan 350): 10.53 tpy × 16
  # AC (6000PE): 28.62 tpy × 8
  # Total = 485.50 tpy (short tons/year). Convert to kg/yr for InMAP.
  if (plant$plant_id[[1]] == "xai") {
    nh3_tpy <- 5.18 * 17 + 10.53 * 16 + 28.62 * 8
    kg_NH3 <- tpy_to_kgyr(nh3_tpy)
  } else {
    kg_NH3 <- 0
  }
  
} else {
  stop("method must be 'EF' or 'PERMIT'.")
}

# ---- Stack parameters (use per-plant overrides if present) ----
height_use <- ifelse(is.na(plant$height_m), STACK_HEIGHT_M_DEFAULT, as.numeric(plant$height_m))
diam_use   <- ifelse(is.na(plant$diam_m),   STACK_DIAM_M_DEFAULT,   as.numeric(plant$diam_m))
temp_use   <- ifelse(is.na(plant$temp_K),   STACK_TEMP_K_DEFAULT,   as.numeric(plant$temp_K))
vel_use    <- ifelse(is.na(plant$vel_ms),   STACK_VEL_MS_DEFAULT,   as.numeric(plant$vel_ms))

# ---- Build a single-point sf and add InMAP fields ----
plant_sf <- st_as_sf(
  tibble(
    plant_id   = plant$plant_id,
    plant_name = plant$plant_name,
    state      = plant$state,
    lat        = plant$lat,
    lon        = plant$lon
  ),
  coords = c("lon","lat"), crs = 4326, remove = FALSE
)

inmap_point <- plant_sf %>%
  transmute(
    plant_id, plant_name, state,
    PM2_5   = round(kg_PM25, 3),
    NOx     = round(kg_NOx,  3),
    SOx     = round(kg_SOx,  3),
    NH3     = round(kg_NH3,  3),
    VOC     = round(kg_VOC,  3),
    height  = height_use,
    diam    = diam_use,
    temp    = temp_use,
    velocity= vel_use
  ) %>%
  st_transform(TARGET_CRS)

# ---- State map plot (using catalog 'state' code) ----
st_abbr <- plant$state[[1]]
if (is.na(st_abbr) || !nzchar(st_abbr)) stop("State code is missing for this plant in the catalog.")

state_counties <- tigris::counties(state = st_abbr, cb = TRUE, year = 2022) %>% st_transform(4326)

gg_state <- ggplot() +
  geom_sf(data = state_counties, fill = "lightblue", color = "grey30", linewidth = 0.2) +
  geom_sf(data = inmap_point, aes(size = PM2_5), color = "red") +
  scale_size_continuous(name = "PM2.5 (kg/yr)", range = c(2.5, 8)) +
  labs(
    title    = plant$plant_name,
    subtitle = paste0("Method: ", method,
                      if (method == "EF") paste0(" | Capacity: ", capacity_mw, " MW | CF: ", uptime) else "",
                      " | Stack H=", height_use, "m, D=", diam_use, "m, v=", vel_use, " m/s, T=", temp_use, " K")
  ) +
  theme_minimal()


# ---- Write shapefile (one file per run) ----
timestamp <- format(Sys.Date(), "%y_%m_%d")
out_dir   <- file.path("output", paste0(timestamp, "_", plant$plant_id))
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

shp_path <- file.path(out_dir, "powerplant.shp")
st_write(inmap_point, dsn = shp_path, delete_layer = TRUE, quiet = TRUE)

# Save plot
ggsave(filename = paste0(out_dir, "/plant_map.pdf"), plot = gg_state,width = 8, height = 8)

message("✅ Wrote shapefile: ", shp_path)
print(inmap_point)
