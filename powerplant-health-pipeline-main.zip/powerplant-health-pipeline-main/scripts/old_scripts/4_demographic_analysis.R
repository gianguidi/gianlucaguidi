## demographics analysis. Run script after running post processing file

install.packages('tigris')
install.packages("sf")
install.packages("remotes")
install.packages("readxl")
install.packages("writexl")
install.packages("tidycensus")
install.packages("tidyverse")

options(tigris_use_cache = TRUE)
library(tigris)
library(ggplot2)
library(sf)
library(dplyr)
library(glue)
library(readxl)
library(writexl)
library(tidycensus)
library(tidyverse)
library(data.table)


### 1) DATA LOADING AND API SETUP ###

#upload results from dispersion model already population aggregated by census tract.
#to aggregate refer to post processing file
tracts_with_pm25 <- read.csv('tracts_with_pm25.csv')
tracts_with_pm25 <- tracts_with_pm25[,c("GEOID","STATE_NAME","STUSPS","NAMELSADCO", "NAME",
                                        "total_pop", "total_pm_pop", "pm25_weighted"
                                        )]


#get API key by setting up e-mail and organization from: 
# https://api.census.gov/data/key_signup.html 

census_api_key("YOUR_KEY_HERE", install = TRUE)
census_api_key("4bddcba08a5490eca5757ef8b7db928e3d5485ef", install = TRUE)
readRenviron("~/.Renviron")  # reload the key

variables <- c(
  total_pop        = "B01003_001",
  pct_black        = "B02001_003",
  pct_white        = "B02001_002",
  pct_asian        = "B02001_005",
  pct_native       = "B02001_004",
  pct_hispanic     = "B03003_003",
  poverty_total    = "B17001_001",
  poverty_below    = "B17001_002",
  med_household_income = "B19013_001",
  med_family_income    = "B19113_001",
  med_property_value   = "B25077_001",
  # New: age 65+ breakdown
  age_65_m_65_66 = "B01001_020",
  age_65_m_67_69 = "B01001_021",
  age_65_m_70_74 = "B01001_022",
  age_65_m_75_79 = "B01001_023",
  age_65_m_80_84 = "B01001_024",
  age_65_m_85_up = "B01001_025",
  age_65_f_65_66 = "B01001_044",
  age_65_f_67_69 = "B01001_045",
  age_65_f_70_74 = "B01001_046",
  age_65_f_75_79 = "B01001_047",
  age_65_f_80_84 = "B01001_048",
  age_65_f_85_up = "B01001_049"
)


demographics <- get_acs(
  geography = "tract",
  state = state.abb,   #set state of interest
  variables = variables,
  year = 2022,
  survey = "acs5",
  output = "wide",
  geometry = FALSE
)



#### 2) DATA PROCESSING  AND JOINING####

demographics <- demographics %>%
  transmute(
    GEOID,
    population = total_popE,
    pct_black  = 100 * pct_blackE / total_popE,
    pct_white  = 100 * pct_whiteE / total_popE,
    pct_asian  = 100 * pct_asianE / total_popE,
    pct_hispanic = 100 * pct_hispanicE / total_popE,
    pct_native = 100 * pct_nativeE / total_popE,
    pct_poverty = 100 * poverty_belowE / poverty_totalE,
    pct_age_above_65 = 100 * (
      age_65_m_65_66E + age_65_m_67_69E + age_65_m_70_74E + 
        age_65_m_75_79E + age_65_m_80_84E + age_65_m_85_upE +
        age_65_f_65_66E + age_65_f_67_69E + age_65_f_70_74E + 
        age_65_f_75_79E + age_65_f_80_84E + age_65_f_85_upE
    ) / total_popE,
    med_household_income = med_household_incomeE,
    med_family_income = med_family_incomeE,
    med_property_value = med_property_valueE
  )

#convert GEOID column to numeric format
demographics$GEOID = as.numeric(demographics$GEOID)

# join tracts data with demographic data
tracts_demographic <- tracts_with_pm25 %>% 
  left_join(demographics, by='GEOID')


##### 3) DEMOGRAPHIC ANALYSIS BY THRESHOLDS AND GEOGRAPHY #####

#### 3.a) demographic analysis by affected area ####

summarize_demo_stats_multi <- function(df, thresholds, pm_column = "pm25_weighted", weight_var = "population") {
  
  # Metrics
  metrics <- c(
    "Total Population Affected",
    "Poverty Rate (%)",
    "White (%)",
    "Black (%)",
    "Hispanic (%)",
    "Asian (%)",
    "Age 65+ (%)",
    "Median Household Income ($)",
    "Median Property Value ($)"
  )
  
  # Function to compute statistics for a given subset
  compute_stats <- function(data) {
    c(
      sum(data[[weight_var]], na.rm = TRUE),
      weighted.mean(data$pct_poverty, data[[weight_var]], na.rm = TRUE),
      weighted.mean(data$pct_white, data[[weight_var]], na.rm = TRUE),
      weighted.mean(data$pct_black, data[[weight_var]], na.rm = TRUE),
      weighted.mean(data$pct_hispanic, data[[weight_var]], na.rm = TRUE),
      weighted.mean(data$pct_asian, data[[weight_var]], na.rm = TRUE),
      weighted.mean(data$pct_age_above_65, data[[weight_var]], na.rm = TRUE),
      mean(data$med_household_income, na.rm = TRUE),
      mean(data$med_property_value, na.rm = TRUE)
    )
  }
  
  # Compute statistics for each threshold
  stats_by_threshold <- map_dfc(thresholds, ~{
    filtered <- df %>% filter(.data[[pm_column]] > .x)
    stat_vec <- compute_stats(filtered)
    colname <- paste0(">", format(.x, scientific = FALSE))
    tibble(!!colname := stat_vec)
  })
  
  # Compute national statistics
  national_stats <- compute_stats(df)
  stats_by_threshold$`National Average` <- national_stats
  
  # Combine with metric labels
  result <- bind_cols(Metric = metrics, stats_by_threshold)
  
  return(result)
}



summary_table <- summarize_demo_stats_multi(
  tracts_demographic,
  thresholds = c(0.001, 0.01, 0.1)
)

print(summary_table)


#### demographic analysis by state and county ####

#analysis by state
state_pm_summary <- tracts_demographic %>%
  group_by(state = STATE_NAME) %>%
  summarise(
    pm = weighted.mean(pm25_weighted, population, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(desc(pm))

print(state_pm_summary)

#analysis by county-state
county_state_pm_summary <- tracts_demographic %>%
  group_by(county = NAMELSADCO, state = STATE_NAME) %>%
  summarise(
    pm = weighted.mean(pm25_weighted, population, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(desc(pm))

print(county_state_pm_summary)

