#!/usr/bin/env Rscript
# -------------------------------------------------------------------------
# Title:   Post‐process InMAP Results & Calculate Pop‐Weighted PM₂.₅
# Author:  Michael Cork
# Date:    2025‐05‐09
# Purpose: Aggregate InMAP grid cells to census tracts & counties,
#          compute population‐weighted mean PM2.5, and save maps & tables.
# Usage:   Rscript scripts/2_post_process.R
# -------------------------------------------------------------------------

# 0. SETUP ------------------------------------------------------------------
# Install required packages if missing:
# install.packages(c("tigris","sf","dplyr","readxl","writexl",
#                    "ggplot2","USAboundaries","RColorBrewer"))

library(tigris)         # census geometries
library(sf)             # spatial data
library(dplyr)          # data wrangling
library(readxl)         # Excel input
library(writexl)        # Excel output
library(ggplot2)        # plotting
library(USAboundaries)  # state boundaries
library(RColorBrewer)   # color palettes
library(scales)

options(tigris_use_cache = TRUE)

# 1. CONFIGURATION ----------------------------------------------------------
timestamp     <- "25_06_27"
identifier    <- "canady"
output_folder <- file.path("output", paste0(timestamp, "_", identifier))
# dir.create(output_folder, showWarnings = FALSE, recursive = TRUE)

# Paolo 
output_folder <- file.path("output/paolo_runs")
inmap_shp <- file.path(output_folder, "inmap_results_25.05.07_MA_analysis.shp")

# Input file paths
inmap_shp <- file.path(output_folder, paste0("inmap_results_", timestamp, "_", identifier, ".shp"))
dc_csv    <- "data/MA_datacenters.csv"
egrid_xlsx<- "data/eGRID2021_data.xlsx"
pm_xlsx   <- "data/egrid-draft-pm-emissions.xlsx"

# Output paths
tracts_csv   <- file.path(output_folder, "tracts_with_pm25.csv")
tracts_pdf   <- file.path(output_folder, "tracts_with_pm25.pdf")
tracts_jpg <- file.path(output_folder, "tracts_with_pm25.jpg")

county_csv   <- file.path(output_folder, "county_with_pm25.csv")
county_pdf   <- file.path(output_folder, "county_with_pm25.pdf")
county_jpg <- file.path(output_folder, "county_with_pm25.jpg")


# 2. LOAD DATA --------------------------------------------------------------
# a) InMAP grid results
inmap_grid <- st_read(inmap_shp, quiet = TRUE)
message("Loaded InMAP grid: ", nrow(inmap_grid), " cells.")

# c) Census tracts and counties (MA only)
tracts_sf <- tracts(state = "SC", cb = FALSE, year = 2024) %>%
  st_transform(st_crs(inmap_grid))

counties_sf <- counties(state = "SC", cb = FALSE, year = 2024) %>%
  st_transform(st_crs(inmap_grid))


# 3. PREPARE GRID CELLS -----------------------------------------------------
# Compute each cell's full area & assign an ID
inmap_cells <- inmap_grid %>%
  mutate(
    cell_id   = row_number(),
    cell_area = as.numeric(st_area(.))
  ) %>%
  select(cell_id, TotalPM25, TotalPop, cell_area, geometry)

# 4. FUNCTION: POP‐WEIGHTED AGGREGATION -------------------------------------
aggregate_to_polygons <- function(polys_sf, poly_id) {
  # Intersect grid cells with target polygons
  overlap <- st_intersection(
    polys_sf    %>% select(!!sym(poly_id)),
    inmap_cells
  ) %>%
    mutate(
      overlap_area = as.numeric(st_area(.)),
      pop_alloc    = TotalPop * (overlap_area / cell_area),
      pm_pop       = TotalPM25 * pop_alloc
    )
  
  # Summarize population‐weighted PM2.5
  summary_tbl <- overlap %>%
    st_drop_geometry() %>%
    group_by(!!sym(poly_id)) %>%
    summarize(
      total_pop     = sum(pop_alloc, na.rm = TRUE),
      total_pm_pop  = sum(pm_pop, na.rm = TRUE),
      pm25_weighted = total_pm_pop / total_pop
    )
  
  # Join back to spatial polygons
  left_join(polys_sf, summary_tbl, by = poly_id)
}

# 5. AGGREGATE TO TRACTS & COUNTIES -----------------------------------------
tracts_out  <- aggregate_to_polygons(tracts_sf,  "GEOID")
counties_out<- aggregate_to_polygons(counties_sf,"GEOID")

# 6. SAVE TABLES ------------------------------------------------------------
write_csv(tracts_out %>% st_drop_geometry(), tracts_csv)
message("Wrote tract‐level CSV: ", tracts_csv)

write_csv(counties_out %>% st_drop_geometry(), county_csv)
message("Wrote county‐level CSV: ", county_csv)


## Create plots
ma_border <- us_states(states = "Massachusetts") %>%
  st_transform(st_crs(polys_sf))

# Compute centroids for labeling
county_centroids <- 
  counties_sf %>%
  st_centroid() %>%
  mutate(NAME = as.character(NAME))  # ensure name is character

tract_exp <- 
  tracts_out %>%
  st_transform(st_crs(counties_sf)) %>%
  filter(!is.na(pm25_weighted)) %>%
  ggplot() +
  geom_sf(aes(fill = pm25_weighted), color = NA) +
  geom_sf(data = counties_sf, fill = "NA", color = "gray50", alpha = 0.5) +
  geom_sf_text(data = county_centroids, aes(label = NAME), size = 4, color = "gray20") +
  scale_fill_distiller(
    palette   = "YlOrRd",
    direction = 1,
    na.value  = "white",
    name      = expression(PM[2.5]~"(µg/"*m^3*")"),
    limits    = c(0, 0.006),
    oob       = squish,
    breaks = c(0.001, 0.003, 0.006)  # manual control
  ) + 
  coord_sf(expand = FALSE) +
  theme_minimal(base_size = 16) +
  theme(
    legend.position = "bottom",
    legend.key.width = unit(1.5, "cm"),
    plot.title      = element_text(hjust = 0.5, face = "bold"),
    plot.subtitle   = element_text(hjust = 0.5)
  ) + 
  theme(
    panel.grid      = element_blank(),
    axis.text       = element_blank(),
    axis.title      = element_blank(),
    axis.ticks      = element_blank()
  )

ggsave(
  filename =  paste0(output_folder, "/pm25_with_legend.jpg"),
  plot     = tract_exp,
  width    = 12,
  height   = 9,
  dpi      = 600
)

# 7. PLOTTING FUNCTION ------------------------------------------------------
plot_pm_map <- function(polys_sf, title, out_jpg) {
  ma_border <- us_states(states = "Massachusetts") %>%
    st_transform(st_crs(polys_sf))
  
  p <- polys_sf %>%
    st_transform(st_crs(counties(state = "MA", cb = TRUE, year = 2022))) %>%
    filter(!is.na(pm25_weighted)) %>%
    ggplot() +
    geom_sf(data = ma_border, fill = "grey95", color = "white") +
    geom_sf(aes(fill = pm25_weighted), color = NA) +
    scale_fill_distiller(
      palette   = "YlOrRd",    # yellow → red
      direction = 1,
      na.value  = "white",
      name      = expression(PM[2.5]~"(µg/"*m^3*")")
    ) +
    coord_sf(expand = FALSE) +
    labs(
      title    = title,
      # subtitle = paste0("Data date: ", timestamp),
      caption  = "Source: InMAP & 2020 Census"
    ) +
    theme_minimal(base_size = 12) +
    theme(
      legend.position = "bottom",
      legend.key.width = unit(1.5, "cm"),
      plot.title      = element_text(hjust = 0.5, face = "bold"),
      plot.subtitle   = element_text(hjust = 0.5)
    ) + 
    theme(
      panel.grid      = element_blank(),
      axis.text       = element_blank(),
      axis.title      = element_blank(),
      axis.ticks      = element_blank()
    )
  
  ggsave(out_jpg, plot = p, width = 10, height = 8, dpi = 600)
  message("Saved plot: ", out_jpg)
}

# 8. PLOT & SAVE ------------------------------------------------------------
plot_pm_map(
  tracts_out,
  "Population-Weighted Mean PM2.5 by MA Census Tract",
  tracts_jpg
)

plot_pm_map(
  counties_out,
  "Population-Weighted Mean PM2.5 by MA County",
  county_jpg
)

# -------------------------------------------------------------------------
# End of script
# -------------------------------------------------------------------------