### This script is currently not being used, a work in progress 

### Script to do health impact function -----------------------------------
library(data.table)
library(tidyverse)
library(USAboundaries)  # for state borders
library(tigris)         # for county geometries
library(ggplot2)
library(sf)

# 1. CONFIGURATION ----------------------------------------------------------
timestamp     <- "25_05_09"
identifier    <- "ma"
output_folder <- file.path("output", paste0(timestamp, "_", identifier))


# Paolo 
output_folder <- file.path("output/paolo_runs")
inmap_shp <- file.path(output_folder, "inmap_results_25.05.07_MA_analysis.shp")

# 2. LOAD & CLEAN CDC WONDER DATA -------------------------------------------

# Assumes your CSV has columns: County Code, Year, Cause, Population,
#    Crude_Rate, Age_Adjusted_Rate, etc.
cdc_raw <- fread("data/MA_data/cdc_wonder_2023_mort.csv")

cdc_2023 <- cdc_raw %>%
  # keep only 2023 & all-cause
  transmute(
    GEOID         = as.integer(`County Code`),
    pop_wonder    = Population,
    rate_crude    = `Crude Rate`,        # per 100 000
  )

# 3. LOAD COUNTY PM2.5 & POP ------------------------------------------------
county_pm <- fread(file.path(output_folder, "county_with_pm25.csv")) %>%
  transmute(
    GEOID          = as.integer(GEOID),
    pm25_weighted,            # µg/m3 change from baseline
    pop_tracked = total_pop   # population used in PM map
  )

# 4. GET MASSACHUSETTS COUNTIES SHAPEFILE ----------------------------------
counties_sf <- counties(state = "MA", cb = TRUE, year = 2022) %>%
  mutate(GEOID = as.numeric(GEOID))

# 5. MERGE ALL DATA TO SHAPE ------------------------------------------------
counties_data <- counties_sf %>%
  left_join(cdc_2023, by = "GEOID") %>%
  left_join(county_pm, by = "GEOID")

# 6. DEFINE BETA COEFFICIENTS ------------------------------------------------
# From COBRA appendix
beta_pope <- 0.011330
beta_wu <- 0.006390

# 7. COMPUTE EXCESS (ATTRIBUTED) DEATHS --------------------------------------
# Here we use crude rate; swap to rate_age_adj if you prefer age-adjusted
counties_mort <- counties_data %>%
  mutate(
    # convert rate_per100k → rate_per_person
    rate_pp = rate_crude / 100000,
    # excess deaths = rate_pp * population * (exp(beta * delta_pm) – 1)
    excess_deaths_pope = rate_pp * pop_tracked * (exp(beta_pope * pm25_weighted) - 1),
    excess_deaths_wu   = rate_pp * pop_tracked * (exp(beta_wu   * pm25_weighted) - 1)
  )

# 8. PLOT -------------------------------------------------------------------
# get MA border in same CRS
ma_border <- 
  us_states(states = "Massachusetts") %>%
  st_transform(st_crs(counties_mort))

# Compute centroids for labeling
county_centroids <- 
  counties_sf %>%
  st_centroid() %>%
  mutate(NAME = as.character(NAME))  # ensure name is character

gg_county <- 
  ggplot(counties_mort) +
  # Fill counties by excess deaths
  geom_sf(aes(fill = excess_deaths_pope), color = "black") +
  # Add county name labels, avoid overlaps
 geom_sf_text(data = county_centroids, aes(label = NAME), size = 3, color = "black") +
  scale_fill_distiller(
    name = "Excess deaths",
    palette = "YlOrRd",
    direction = 1,
    na.value = "grey90",
    oob = scales::squish
  ) + 
  coord_sf(expand = FALSE) +
  # Minimal theme with removed axis/grid clutter
  theme_minimal(base_size = 12) +
  theme(
    panel.grid      = element_blank(),
    axis.text       = element_blank(),
    axis.title      = element_blank(),
    axis.ticks      = element_blank()
  ) +
  labs(
    title = "Data Center Attributed Excess Deaths in MA Counties (2023)"
  )

# Save plot 
ggsave(
  filename = file.path(output_folder, "excess_deaths_map.pdf"),
  plot     = gg_county,
  width    = 10,
  height   = 8
)

ggsave(
  filename = file.path(output_folder, "excess_deaths_map.jpg"),
  plot     = gg_county,
  width    = 10,
  height   = 8,
  dpi      = 600
)

# Apply statistical value of a life to mortality data
# Taken from 2023 health end point data in COBRA manual 
val_life <- 14012045.11

cost_millions <- sum(counties_mort$excess_deaths_pope * val_life) / 1000000


### Now can we try running at the census tract level 
# 3. LOAD census
tracts_pm <- fread(file.path(output_folder, "tracts_with_pm25.csv")) %>%
  transmute(
    GEOID          = as.numeric(GEOID),
    pm25_weighted,            # µg/m3 change from baseline
    pop_tracked = total_pop   # population used in PM map
  )

# 4. Now can we work at the Census tract level -----------------------------------------
# --- Load USALEEP and build GEOID -----------------------------------------
mort <-  readxl::read_excel("data/USALEEP_mort/tract_mort_2020/BenMAP_Ready_USALEEP_AllCauseRates_2020.xlsx") %>%
  mutate(GEOID = sprintf("%05d%06d", Row, Column)) %>%      # county + tract
  select(GEOID, Start_Age = `Start Age`, End_Age = `End Age`, mort_rate = Value)

# Load in the ACS data
acs <- fread("data/MA_data/2022_tract_acs5.csv")

# ---------- 2. Convert ACS % to counts -----------------------------------
acs_long <- acs %>%
  select(year, GEOID, population, pct_age_under_5, pct_age_5_to_9, pct_age_10_to_14,
         pct_age_15_to_17, pct_age_18_to_19, pct_age_20, pct_age_21, pct_age_22_to_24, 
         pct_age_25_to_29, pct_age_30_to_34, pct_age_35_to_39, pct_age_40_to_44,
         pct_age_45_to_49, pct_age_50_to_54, pct_age_55_to_59, pct_age_60_to_61,
         pct_age_62_to_64, pct_age_65_to_66, pct_age_67_to_69, pct_age_70_to_74,
         pct_age_75_to_79, pct_age_80_to_84, pct_age_over_85) %>%
  pivot_longer(cols = starts_with("pct_"), names_to = "pct_var", values_to = "pct") %>%
  mutate(pop = pct * population)   # 'population' column holds total tract pop

# ---------- 3. Build tract-specific pop in USALEEP bins ------------------
make_bin <- function(df, vars, frac = NULL) {
  sel <- df %>% filter(pct_var %in% vars)
  if (!is.null(frac)) sel$pop <- sel$pop * frac
  sum(sel$pop, na.rm = TRUE)
}

bin_map <- tribble(
  ~bin,       ~vars,                                                 ~frac,
  "0",        "pct_age_under_5",                                      0.20,
  "1_4",      "pct_age_under_5",                                      0.80,
  "5_14",     c("pct_age_5_to_9","pct_age_10_to_14"),                 NA,
  "15_24",    c("pct_age_15_to_17","pct_age_18_to_19","pct_age_20",
                "pct_age_21","pct_age_22_to_24"),                      NA,
  "25_34",    c("pct_age_25_to_29","pct_age_30_to_34"),               NA,
  "35_44",    c("pct_age_35_to_39","pct_age_40_to_44"),               NA,
  "45_54",    c("pct_age_45_to_49","pct_age_50_to_54"),               NA,
  "55_64",    c("pct_age_55_to_59","pct_age_60_to_61","pct_age_62_to_64"), NA,
  "65_74",    c("pct_age_65_to_66","pct_age_67_to_69","pct_age_70_to_74"), NA,
  "75_84",    c("pct_age_75_to_79","pct_age_80_to_84"),               NA,
  "85_99",    "pct_age_over_85",                                      NA
)

pop_bins <- acs %>%
  rowwise() %>%
  mutate(across(bin_map$bin,
                ~ make_bin(acs_long[acs_long$GEOID == GEOID,],
                           bin_map$vars[bin_map$bin == cur_column()],
                           bin_map$frac[bin_map$bin == cur_column()]), .names = "pop_{col}")) %>%
  ungroup() %>%
  select(GEOID, starts_with("pop_")) %>%
  pivot_longer(-GEOID, names_to = "bin", values_to = "pop") %>%
  mutate(bin = gsub("pop_", "", bin))

# --- Load ACS population table -------------------------------------------
pop <- fread("data/MA_data/2022_tract_acs5.csv")   # one row per tract

# helper to pick(pop column) or 0 if missing
g <- function(df, nm) ifelse(nm %in% names(df), df[[nm]], 0)

pop_long <- pop %>% transmute(
  GEOID,
  pop_0      = g(., "pop_total_under_5") * 0.20,
  pop_1_4    = g(., "pop_total_under_5") * 0.80,
  pop_5_14   = g(., "pop_total_5_to_9") + g(., "pop_total_10_to_14"),
  pop_15_24  = g(., "pop_total_15_to_17") + g(., "pop_total_18_to_19") +
    g(., "pop_total_20") + g(., "pop_total_21") + g(., "pop_total_22_to_24"),
  pop_25_34  = g(., "pop_total_25_to_29") + g(., "pop_total_30_to_34"),
  pop_35_44  = g(., "pop_total_35_to_39") + g(., "pop_total_40_to_44"),
  pop_45_54  = g(., "pop_total_45_to_49") + g(., "pop_total_50_to_54"),
  pop_55_64  = g(., "pop_total_55_to_59") + g(., "pop_total_60_to_61") +
    g(., "pop_total_62_to_64"),
  pop_65_74  = g(., "pop_total_65_to_66") + g(., "pop_total_67_to_69") +
    g(., "pop_total_70_to_74"),
  pop_75_84  = g(., "pop_total_75_to_79") + g(., "pop_total_80_to_84"),
  pop_85_99  = g(., "pop_total_over_85")
) %>%
  pivot_longer(-GEOID, names_to = "age_bin", values_to = "pop")

tracts_sf <- tracts(state = "MA", cb = TRUE, year = 2022)

# Extract mortality data at the census tract level 
local_mort <- readxl::read_excel(path = "data/USALEEP_mort/tract_mort_2020/BenMAP_Ready_USALEEP_AllCauseRates_2020.xlsx")

# Add on the GEOID so I can merge with the tracts
local_mort <- 
  local_mort %>%
  mutate(GEOID = sprintf("%05d%06d", Row, Column))  # 5 digits for 'Row' which is county, 6 for 'Column' which is county)

# Load in the population 
acs_pop_data <- fread("data/MA_data/2022_tract_acs5.csv")


merged <- 
  tracts_sf %>% left_join(local_mort, by = "GEOID") 

intersect(tracts_sf$GEOID, local_mort$GEOID) %>% length() # 0

merged %>% 
  ggplot() + 
  geom_sf(aes(fill = Value), color = "black")


