#!/usr/bin/env Rscript
# -------------------------------------------------------------------------
# Title    : Post-process InMAP Results & Map High-Exposure Counties
# Author   : Michael Cork
# Date     : 2025-05-09 (updated)
# Purpose  : Aggregate grid to tracts/counties, compute population-weighted 
#            PM₂.₅, and map only the counties exceeding 1e-3 µg/m³.
# -------------------------------------------------------------------------

# 0. SETUP ------------------------------------------------------------------
library(sf)
library(dplyr)
library(readr)
library(ggplot2)
library(tigris)
library(tidyr)
options(tigris_use_cache = TRUE)

# 1. CONFIGURATION ----------------------------------------------------------
timestamp     <- "25_06_29"
identifier    <- "canady_cluster"
out_dir       <- file.path("output", paste0(timestamp, "_", identifier))
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

# Input & output paths
inmap_shp   <- file.path(out_dir, sprintf("inmap_results_%s_%s.shp", timestamp, identifier))
tracts_csv  <- file.path(out_dir, "tracts_with_pm25.csv")
counties_csv<- file.path(out_dir, "counties_with_pm25.csv")
map_png     <- file.path(out_dir, "tracts_zoomed_pm25.png")

# 2. LOAD SPATIAL DATA ------------------------------------------------------
grid       <- st_read(inmap_shp, quiet = TRUE)
tracts_sf  <- tracts(cb = TRUE, year = 2024)   %>% st_transform(st_crs(grid))
counties_sf<- counties(cb = TRUE, year = 2024) %>% st_transform(st_crs(grid))

message("✔ Loaded grid (", nrow(grid), " cells), tracts and counties.")

# 3. PREPARE GRID FOR AGGREGATION -------------------------------------------
cells <- grid %>%
  mutate(
    cell_id   = row_number(),
    cell_area = as.numeric(st_area(.))
  ) %>%
  select(cell_id, TotalPM25, TotalPop, cell_area, geometry)


# 4. POP-WEIGHTED AGGREGATION FUNCTION -------------------------------------
# This function takes an sf of target polygons (e.g. tracts or counties) and
# an sf of InMAP grid cells (pre-loaded as `cells`), then:
#   1. Intersects each polygon with overlapping grid cells
#   2. Allocates cell population (TotalPop) proportionally by area of overlap
#   3. Allocates PM2.5 mass (TotalPM25) to those same people
#   4. Sums (PM2.5 × pop) and divides by total pop to get a true population-weighted mean
#
# Assumptions:
# - Population and PM2.5 are uniformly distributed across each grid cell.
# - Partial overlaps receive the same per-area density as the full cell.
# - No edge effects beyond the cell-level aggregation.

aggregate_pw <- function(polys_sf, id_col) {
  # 1) Intersect polygons with grid cells
  overlap <- st_intersection(
    polys_sf %>% select(!!sym(id_col)),
    cells
  )
  
  # 2) Compute overlap areas, allocate population & PM to each overlap
  overlap <- overlap %>%
    mutate(
      overlap_area = as.numeric(st_area(.)),                 # m² of polygon ∩ cell
      pop_alloc    = TotalPop * (overlap_area / cell_area),  # pop in that overlap
      pm_pop       = TotalPM25 * pop_alloc                   # PM₂.₅·pop in that overlap
    )
  
  # 3) Summarize to per-polygon totals & compute weighted mean
  summary_tbl <- overlap %>%
    st_drop_geometry() %>%
    group_by(!!sym(id_col)) %>%
    summarize(
      total_pop     = sum(pop_alloc, na.rm = TRUE),
      total_pm_pop  = sum(pm_pop,   na.rm = TRUE),
      pm25_weighted = total_pm_pop / total_pop              # µg/m³, population-weighted
    )
  
  # 4) Join back to the original polygons
  result <- polys_sf %>%
    left_join(summary_tbl, by = id_col)
  
  return(result)
}

tracts_out   <- aggregate_pw(tracts_sf,  "GEOID")
counties_out <- aggregate_pw(counties_sf, "GEOID")

# Save CSVs
write_csv(tracts_out %>% st_drop_geometry(), tracts_csv)
write_csv(counties_out %>% st_drop_geometry(), counties_csv)
message("✔ Wrote CSVs to ", out_dir)

# Write shapefiles to share with collaborators
tracts_out_shp <- 
  tracts_out %>% filter(pm25_weighted > 1e-3) %>% 
  select(STATEFP, COUNTYFP, TRACTCE, GEOID, NAMELSAD, STUSPS, STATE_NAME, total_pop, pm25 = pm25_weighted)

counties_out_shp <- 
  counties_out %>% filter(pm25_weighted > 1e-3) %>% 
  select(STATEFP, COUNTYFP, COUNTYNS, GEOID, NAME, NAMELSAD, STUSPS, STATE_NAME, total_pop, pm25 = pm25_weighted)


# 5. FILTER & SET UP LABELS -----------------------------------------------
# Keep only counties with weighted PM2.5 > 1e-3
counties_filt <- counties_out %>% filter(pm25_weighted > 1e-3)

county_labels <- st_centroid(counties_filt) %>%
  st_coordinates() %>%
  as_tibble() %>%
  bind_cols(counties_filt %>% st_drop_geometry()) %>%
  select(NAME, X = X, Y = Y)

# Manually nudge overlapping “Montgomery” & “Toombs”
label_nudges <- tibble(
  NAME    = c("Montgomery", "Toombs"),
  nudge_x = c(0, 0),
  nudge_y = c( 10000,-10000)
)

county_labels <- county_labels %>%
  left_join(label_nudges, by = "NAME") %>%
  replace_na(list(nudge_x = 0, nudge_y = 0))

# 6. STATE CONTEXT (SC & GA) -----------------------------------------------
states_sub <- states(cb = TRUE, year = 2024) %>%
  filter(STUSPS %in% c("SC", "GA")) %>%
  st_transform(st_crs(grid))

state_labels <- st_centroid(states_sub) %>%
  st_coordinates() %>%
  as_tibble() %>%
  bind_cols(states_sub %>% st_drop_geometry()) %>%
  select(STUSPS, X, Y) %>%
  mutate(
    nudge_x = ifelse(STUSPS=="GA",  50000, 0),
    nudge_y = ifelse(STUSPS=="SC", 50000, 0)
  )

# 7. DEFINE PLOT WINDOW -----------------------------------------------------
bb   <- st_bbox(counties_filt)
dx   <- bb$xmax - bb$xmin; dy <- bb$ymax - bb$ymin
xlim <- c(bb$xmin - 0.2*dx, bb$xmax + 0.2*dx)
ylim <- c(bb$ymin - 0.2*dy, bb$ymax + 0.2*dy)

# 8. DRAW MAP ---------------------------------------------------------------
tract_plot <- ggplot() +
  # High‐exposure tracts
  geom_sf(data = tracts_out  %>% filter(pm25_weighted > 1e-3),
          aes(fill = pm25_weighted),
          color = NA) +
  # County outlines
  geom_sf(data = counties_filt, fill = NA, color = "gray50") +
  # Power plant point
  geom_sf(data = st_read(file.path(out_dir, "powerplant.shp")),
          color = "blue", size = 2) +
  # County labels
  geom_text(
    data    = county_labels,
    aes(x = X, y = Y, label = NAME),
    nudge_x = county_labels$nudge_x,
    nudge_y = county_labels$nudge_y,
    size    = 3, color = "gray20"
  ) +
  # State outlines
  geom_sf(data = states_sub, fill = NA, color = "black", size = 0.7) +
  # State labels
  geom_text(
    data    = state_labels,
    aes(x = X, y = Y, label = STUSPS),
    nudge_x = state_labels$nudge_x,
    nudge_y = state_labels$nudge_y,
    fontface = "bold", size = 5
  ) +
  # make the fill scale longer
  scale_fill_distiller(
    palette   = "YlOrRd",
    direction = 1,
    name      = expression(PM[2.5]~"(µg/"*m^3*")"),
    guide     = guide_colorbar(
      barwidth  = unit(8, "cm"),   # <-- wider bar
      barheight = unit(0.5, "cm"), # <-- thicker bar
      title.position = "top",      
      title.hjust    = 0.5         
    )
  ) +
  theme(
    legend.position    = "bottom",
    legend.direction   = "horizontal",
    legend.key.width   = unit(8, "cm"),   # ensure key matches
    legend.key.height  = unit(0.5, "cm")
  ) + 
  coord_sf(xlim = xlim, ylim = ylim, expand = FALSE) +
  theme_minimal(base_size = 14) +
  theme(
    legend.position = "bottom",
    panel.grid      = element_blank(),
    axis.text       = element_blank(),
    axis.ticks      = element_blank(),
    axis.title      = element_blank()
  )

# 9. SAVE -------------------------------------------------------------------
ggsave(filename = paste0(out_dir, "/tract_map.png"), tract_plot, width = 10, height = 10, dpi = 600)
message("✔ Saved tract map")

# Create county map
county_plot <- ggplot() +
  # High‐exposure tracts
  geom_sf(data = counties_out %>% filter(pm25_weighted > 1e-3),
          aes(fill = pm25_weighted),
          color = NA) +
  # County outlines
  geom_sf(data = counties_filt, fill = NA, color = "gray50") +
  # Power plant point
  geom_sf(data = st_read(file.path(out_dir, "powerplant.shp")),
          color = "blue", size = 2) +
  # County labels
  geom_text(
    data    = county_labels,
    aes(x = X, y = Y, label = NAME),
    nudge_x = county_labels$nudge_x,
    nudge_y = county_labels$nudge_y,
    size    = 3, color = "gray20"
  ) +
  # State outlines
  geom_sf(data = states_sub, fill = NA, color = "black", size = 0.7) +
  # State labels
  geom_text(
    data    = state_labels,
    aes(x = X, y = Y, label = STUSPS),
    nudge_x = state_labels$nudge_x,
    nudge_y = state_labels$nudge_y,
    fontface = "bold", size = 5
  ) +
  # make the fill scale longer
  scale_fill_distiller(
    palette   = "YlOrRd",
    direction = 1,
    name      = expression(PM[2.5]~"(µg/"*m^3*")"),
    guide     = guide_colorbar(
      barwidth  = unit(8, "cm"),   # <-- wider bar
      barheight = unit(0.5, "cm"), # <-- thicker bar
      title.position = "top",      
      title.hjust    = 0.5         
    )
  ) +
  theme(
    legend.position    = "bottom",
    legend.direction   = "horizontal",
    legend.key.width   = unit(8, "cm"),   # ensure key matches
    legend.key.height  = unit(0.5, "cm")
  ) + 
  coord_sf(xlim = xlim, ylim = ylim, expand = FALSE) +
  theme_minimal(base_size = 14) +
  theme(
    legend.position = "bottom",
    panel.grid      = element_blank(),
    axis.text       = element_blank(),
    axis.ticks      = element_blank(),
    axis.title      = element_blank()
  )

# 9. SAVE -------------------------------------------------------------------
ggsave(filename = paste0(out_dir, "/county_map.png"), county_plot, width = 10, height = 10, dpi = 600)
message("✔ Saved county map")

# 1) pick your threshold
tract_zoom <- tracts_out %>% filter(pm25_weighted > 0.01)

# 2) compute its bounding box
bb_zoom <- st_bbox(tract_zoom)

# 3) add a 10% margin on each side
dx <- bb_zoom$xmax - bb_zoom$xmin
dy <- bb_zoom$ymax - bb_zoom$ymin

xlim_zoom <- c(bb_zoom$xmin - 0.1*dx,
               bb_zoom$xmax + 0.1*dx)
ylim_zoom <- c(bb_zoom$ymin - 0.1*dy,
               bb_zoom$ymax + 0.1*dy)


tract_plot_zoom <- 
  ggplot() +
  # 1) High-exposure tracts
  geom_sf(data = tract_zoom,
          aes(fill = pm25_weighted),
          color = NA) +
  
  # 2) All county outlines (or you can filter to impacted ones)
  geom_sf(data = counties_out,
          fill = NA, color = "gray50") +
  
  # 3) State borders
  geom_sf(data = states_sub,
          fill = NA, color = "black", size = 2) +
  
  # 4) Plant location
  geom_sf(data = st_read(file.path(out_dir, "powerplant.shp")),
          color = "blue", size = 2) +
  
  # 5) County labels (with any manual nudges baked into county_labels)
  geom_text(data = county_labels,
            aes(x = X, y = Y, label = NAME),
            size = 3, color = "gray20") +
  
  # 6) State labels
  geom_text(data = state_labels,
            aes(x = X, y = Y, label = STUSPS),
            nudge_x = state_labels$nudge_x,
            nudge_y = state_labels$nudge_y,
            fontface = "bold", size = 5) +
  
  # 7) Color scale with custom horizontal guide
  scale_fill_distiller(
    palette = "YlOrRd", direction = 1,
    name    = expression(PM[2.5]~"(µg/"*m^3*")"),
    guide   = guide_colorbar(
      direction      = "horizontal",
      title.position = "top",
      title.hjust    = 0.5,
      barwidth       = unit(6, "cm"),
      barheight      = unit(0.4, "cm")
    )
  ) +
  
  # 8) Zoom to high-exposure area
  coord_sf(xlim = xlim_zoom, ylim = ylim_zoom, expand = FALSE) +
  
  # 9) Clean theme
  theme_minimal(base_size = 14) +
  theme(
    legend.position  = "bottom",
    legend.direction = "horizontal"
  ) +
  theme(
    panel.grid = element_blank(),
    axis.text  = element_blank(),
    axis.ticks = element_blank(),
    axis.title = element_blank()
  )

ggsave(filename = paste0(out_dir, "/tract_map_zoom.png"), tract_plot_zoom, width = 10, height = 10, dpi = 600)
message("✔ Saved Zoom map")


#### now plot at the grid cell level 
# 1) pick your threshold
grid_zoom <- cells %>% filter(TotalPM25 > 0.01)

# 2) compute its bounding box
bb_zoom <- st_bbox(grid_zoom)

# 3) add a 10% margin on each side
dx <- bb_zoom$xmax - bb_zoom$xmin
dy <- bb_zoom$ymax - bb_zoom$ymin

xlim_zoom <- c(bb_zoom$xmin - 0.1*dx,
               bb_zoom$xmax + 0.1*dx)
ylim_zoom <- c(bb_zoom$ymin - 0.1*dy,
               bb_zoom$ymax + 0.1*dy)

cell_plot_zoom <- 
  ggplot() +
  # 1) High-exposure tracts
  geom_sf(data = grid_zoom,
          aes(fill = TotalPop),
          color = NA) +
  
  # 2) All county outlines (or you can filter to impacted ones)
  geom_sf(data = counties_out,
          fill = NA, color = "gray50") +
  
  # 3) State borders
  geom_sf(data = states_sub,
          fill = NA, color = "black", size = 2) +
  
  # 4) Plant location
  geom_sf(data = st_read(file.path(out_dir, "powerplant.shp")),
          color = "blue", size = 2) +
  
  # 5) County labels (with any manual nudges baked into county_labels)
  geom_text(data = county_labels,
            aes(x = X, y = Y, label = NAME),
            size = 3, color = "gray20") +
  
  # 6) State labels
  geom_text(data = state_labels,
            aes(x = X, y = Y, label = STUSPS),
            nudge_x = state_labels$nudge_x,
            nudge_y = state_labels$nudge_y,
            fontface = "bold", size = 5) +
  
  # 7) Color scale with custom horizontal guide
  scale_fill_distiller(
    palette = "YlOrRd", direction = 1,
    name    = expression(PM[2.5]~"(µg/"*m^3*")"),
    guide   = guide_colorbar(
      direction      = "horizontal",
      title.position = "top",
      title.hjust    = 0.5,
      barwidth       = unit(6, "cm"),
      barheight      = unit(0.4, "cm")
    )
  ) +
  
  # 8) Zoom to high-exposure area
  coord_sf(xlim = xlim_zoom, ylim = ylim_zoom, expand = FALSE) +
  
  # 9) Clean theme
  theme_minimal(base_size = 14) +
  theme(
    legend.position  = "bottom",
    legend.direction = "horizontal"
  ) +
  theme(
    panel.grid = element_blank(),
    axis.text  = element_blank(),
    axis.ticks = element_blank(),
    axis.title = element_blank()
  )


### Visualize towns with high exposure percentage
# — 0) Make sure your cells sf has an explicit cell_id & its full area
cells2 <- cells %>%
  mutate(
    cell_id   = row_number(),
    cell_area = as.numeric(st_area(geometry)),  # area of each full cell
    TotalPM25 = TotalPM25,
    TotalPop  = TotalPop
  )

# — 1) Keep only the town NAME (and geometry) that you care about
towns2 <- places(state = "SC", cb = TRUE, year = 2024) %>%
  select(NAME) %>%
  st_transform(st_crs(cells2))

# — 2) Spatial intersection: this gives one row per (cell × town) overlap
#     and carries along cell_id, cell_area, TotalPM25, TotalPop, NAME
overlap <- st_intersection(cells2, towns2)

# — 3) Compute overlap_area, fraction, allocated pop & pm
overlap <- overlap %>%
  mutate(
    overlap_area = as.numeric(st_area(geometry)),        # area of the intersected polygon
    area_frac    = overlap_area / cell_area,             # fraction of cell in this town
    pop_alloc    = TotalPop  * area_frac,                # pop in that overlap
    pm_pop       = TotalPM25 * pop_alloc                 # PM₂.₅·pop in that overlap
  )

# — 4) Summarize per town
town_pm_weighted <- overlap %>%
  st_drop_geometry() %>%
  group_by(NAME) %>%
  summarize(
    total_pop        = sum(pop_alloc, na.rm = TRUE),
    total_pm_pop     = sum(pm_pop,   na.rm = TRUE),
    pm25_weighted    = total_pm_pop / total_pop,       # population‐weighted average
    max_cell_pm      = max(TotalPM25, na.rm = TRUE),
    n_overlaps       = n()
  ) %>%
  filter(n_overlaps > 0)

# — 5) (Optional) join back to town polygons for mapping
towns_exposed <- towns2 %>%
  left_join(town_pm_weighted, by = "NAME") %>%
  filter(!is.na(pm25_weighted))

# Filter to towns with high PM2.5 percentage
towns_exposed %>% filter(pm25_weighted > 0.05) %>% mutate(town_area = st_area(.))


# Percentage totals 

#### 1.  Add a person-µg metric to each tract  ####
tracts_demographic <- tracts_out %>%
  mutate(pop_exposure = pm25_weighted * total_pop)   # ΔPM × pop

#### 2.  Aggregate to county level  ####
county_impact <- tracts_demographic %>%
  group_by(state = STATE_NAME,
           county = NAMELSADCO) %>%
  summarise(
    total_pop_exposure = sum(pop_exposure, na.rm = TRUE),
    avg_increment      = weighted.mean(pm25_weighted, population, na.rm = TRUE),
    population         = sum(population, na.rm = TRUE),
    .groups = "drop"
  )

#### 3.  Compute each county’s share of total impact  ####
county_impact <- county_impact %>%
  mutate(
    share_total_exposure = total_pop_exposure /
      sum(total_pop_exposure)
  ) %>%
  arrange(desc(share_total_exposure))

#### 4.  Inspect the results  ####
county_impact %>%
  select(state, county, population,
         share_total_exposure, avg_increment) %>%
  mutate(share_total_exposure =
           scales::percent(share_total_exposure, accuracy = 0.01))
