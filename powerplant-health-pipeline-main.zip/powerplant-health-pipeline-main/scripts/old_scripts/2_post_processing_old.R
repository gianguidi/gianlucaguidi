####### ####### ####### ####### ####### ####### ####### #######
####### ####### ####### ####### ####### ####### ####### ####### 
####### INAMP at FINEST RESOLUTION  #######  #######  #######
####### ####### ####### ####### ####### ####### ####### ####### 
####### ####### ####### ####### ####### ####### ####### ####### 
install.packages('tigris')
install.packages("sf")
install.packages("remotes")
install.packages("pbmcapply")
install.packages("readxl")
install.packages("writexl")
remotes::install_github("ropensci/USAboundaries")
remotes::install_github("ropensci/USAboundariesData")

options(tigris_use_cache = TRUE)
library(tigris)
library(ggplot2)
library(sf)
library(raster)
library(tictoc)
library(dplyr)
library(sf)
library(data.table)
library(pbmcapply)
library(glue)
library(readxl)
library(writexl)

inmap_results <-st_read(
  "insert_run_path/inmap_results_YY.MM.DD_identifier.shp")
st_crs(inmap_results)


tracts_sf <- tracts( cb=TRUE, state=NULL)
tracts_sf <- tracts_sf[!(tracts_sf$STATEFP %in% c("02", "15", "66", "72", "60", "69", "78")), ]


tracts_sf <- st_transform(tracts_sf, crs = st_crs(inmap_results))

st_crs(inmap_results)
st_crs(tracts_sf)

max(inmap_results$TotalPM25)

inmap_results

nrow(inmap_results)
colSums(is.na(inmap_results))
inmap_results

states_use <- c( state.name[!( state.name %in% c( 'Hawaii', 'Alaska'))], 'Washington DC')
p4s <- "EPSG:4326"
us.sf <- USAboundaries::us_states( states = states_use) %>%
  st_transform( crs = p4s)

ggplot( (inmap_results)
        ,
        aes( fill =  TotalPM25)) +
  geom_sf( size = 0, alpha = .9, color = NA) +
  geom_sf( data = us.sf, fill = NA, size = .9, color = 'lightgrey') +
  #scale_fill_gradient( high = 'red', low = 'green',
  #                    limits = c(0,0.05), 
  #                   oob = scales::squish) +
  scale_fill_viridis_c(option='magma',
                       limits = c(0,.5),
                       oob = scales::squish, alpha =0.9)+
  
  expand_limits( fill = 1) +
  theme_minimal() +
  theme( legend.position = 'bottom',
         legend.text = element_text( angle = 30))  +
  ggtitle('Power Plants Total PM25 Emissions - InMAP grid (µg/m3)') +
  theme(plot.title = element_text(hjust = 0.5)) 


#### convert inmap cells into tracts 
tracts_sf

#Function 

#' `sf` polygon to `sf` polygon variable aggregation
#' 
#' @param x_poly_sf object of `sf`class, with corresponding geometry class `sfc_POLYGON`, `sfc_MULTIPOLYGON`, `sfc_GEOMETRY`. The corresponding `tibble` should contain a variable that will be aggregated.
#' @param y_poly_sf object of `sf`class, with corresponding geometry class `sfc_POLYGON`, `sfc_MULTIPOLYGON`, `sfc_GEOMETRY`.
#' @param y_id name of variable in `y_poly_sf` that contains the polygon IDs.
#' @param x_var name of the variable in `x_poly_sf` that will be "aggregated".
#' @param fn "aggregation function" function 
#'
#' @return A `tibble` containing a polygon ID in `y_poly_sf` and an associated variable which is obtained by applying an aggregation function over values in `x_poly_sf`.
# Updated function with progress bar
var_poly_to_poly <- function(
    x_poly_sf, 
    y_poly_sf, 
    y_id, 
    x_var, 
    fn = mean
) {
  # Initialize the column to store results
  y_poly_sf[[x_var]] <- 0
  
  # Initialize progress bar
  pb <- progress::progress_bar$new(
    format = "  Aggregating [:bar] :percent in :elapsed",
    total = nrow(y_poly_sf), clear = FALSE, width = 60
  )
  
  for (i in 1:nrow(y_poly_sf)) {
    pb$tick()  # Update progress bar
    
    y_i_sf <- dplyr::select(y_poly_sf[i, ], "geometry")
    
    suppressWarnings({
      suppressMessages({
        x_i_sf <- try(
          dplyr::select(st_crop(x_poly_sf, raster::extent(y_i_sf)), c(x_var, "geometry")),
          silent = TRUE
        ) %>% st_drop_geometry()
      })
    })
    
    if (!inherits(x_i_sf, "try-error")) {
      y_poly_sf[[x_var]][i] <- fn(as.numeric(unlist(x_i_sf[x_var])))
    } else {
      y_poly_sf[[x_var]][i] <- as.numeric(NA)
    }
  }
  
  return(
    y_poly_sf %>% 
      st_drop_geometry() %>% 
      dplyr::select(y_id, x_var)
  )
}




##


tracts_exp_totPM25 <- var_poly_to_poly(inmap_results, tracts_sf, 
                                                                 'GEOID', 'TotalPM25')





###### 


# save it 
write.csv(tracts_exp_totPM25, "insert_run_path/tracts_YY.MM.DD_identifier.csv", row.names=FALSE)

# load it
tracts_exp_totPM25 = read.csv("insert_run_path/tracts_YY.MM.DD_identifier.csv")

## merge with map to get polygons
tracts_sf$GEOID = as.numeric(tracts_sf$GEOID)
tracts_exp_totPM25$GEOID = as.numeric(tracts_exp_totPM25$GEOID)


tracts_exp_totPM25

tracts_exp_totPM25_tracts <- tracts_sf %>% 
  left_join(tracts_exp_totPM25)
tracts_exp_totPM25_tracts

tracts_exp_totPM25_tracts_excel <- st_set_geometry(tracts_exp_totPM25_tracts, NULL)
write_xlsx(tracts_exp_totPM25_tracts_excel, "insert_run_path/census_tracts_YY.MM.DD_identifier.xlsx")

max(tracts_exp_totPM25_tracts$TotalPM25)
# all exposure by tract
tracts_exp_totPM25_virginia = tracts_exp_totPM25_tracts[(tracts_exp_totPM25_tracts$STATE_NAME == 'Virginia'),]
tracts_exp_totPM25_virginia



### proportion allocated to virginia
# Calculate weighted PM2.5 for each tract
tracts_exp_totPM25_tracts <- tracts_exp_totPM25_tracts %>%
  mutate(WeightedPM25 = TotalPM25 * (ALAND + AWATER))

# Calculate the total weighted PM2.5 for the entire dataset
total_weighted_pm25 <- sum(tracts_exp_totPM25_tracts$WeightedPM25, na.rm = TRUE)

# Filter the data for Virginia and calculate the weighted sum
virginia_data <- tracts_exp_totPM25_tracts %>%
  filter(STATE_NAME == "Virginia") %>%
  summarize(TotalWeightedPM25 = sum(WeightedPM25, na.rm = TRUE))

# Calculate the percentage of weighted PM2.5 in Virginia relative to the total
percentage_virginia <- (virginia_data$TotalWeightedPM25 / total_weighted_pm25) * 100

# Filter the data for Pittsylvania County in Virginia and calculate the weighted sum
pittsylvania_data <- tracts_exp_totPM25_tracts %>%
  filter(STATE_NAME == "Virginia", NAMELSADCO == "Pittsylvania County") %>%
  summarize(TotalWeightedPM25 = sum(WeightedPM25, na.rm = TRUE))

# Calculate the percentage of weighted PM2.5 in Pittsylvania County relative to the total
percentage_pittsylvania <- (pittsylvania_data$TotalWeightedPM25 / total_weighted_pm25) * 100

# Output the results
list(
  Virginia_Percentage = percentage_virginia,
  Pittsylvania_Percentage = percentage_pittsylvania
)



#####plot totPM25  ORIGINAL######
ggplot( tracts_exp_totPM25_virginia,
        aes( fill =  TotalPM25)) +
  geom_sf( size = 0, alpha = .9, color = NA) +
  #geom_sf( data = us.sf, fill = NA, size = .5, linewidth=.005) +
  #scale_fill_gradient( high = 'red', low = 'white',
  #limits = c(1,2), 
  #                    oob = scales::squish) +
  scale_fill_viridis_c(option='magma',limits = c(0,.5),oob = scales::squish, alpha =0.9)+
  
  expand_limits( fill = 0) +
  theme_minimal() +
  theme( legend.position = 'bottom',
         legend.text = element_text( angle = 30))  +
  ggtitle('Power Plants Total PM2.5 Emissions - Census Tract Level - InMAP (µg/m3)') +
  theme(plot.title = element_text(hjust = 0.5))


# Virginia data aggregated df by county
virginia_counties <- tracts_exp_totPM25_virginia %>%
  group_by(NAMELSADCO) %>%
  summarize(geometry = st_union(geometry), .groups = "drop")

virginia_counties <- virginia_counties %>%
  mutate(NAMELSADCO = gsub(" County", "", NAMELSADCO))


### Census Tract Virginia specific plot REVERSE MAGMA ###
ggplot(tracts_exp_totPM25_virginia, aes(fill = TotalPM25)) +
  geom_sf(size = 0, alpha = .9, color = NA) +
  geom_sf(data = virginia_counties, fill = NA, color = "grey", size = 0.5) + 
  scale_fill_viridis_c(option = 'magma', limits = c(0, max(tracts_exp_totPM25_tracts$TotalPM25)), direction = -1, oob = scales::squish, alpha = 0.9) +
  expand_limits(fill = 0) +
  theme_minimal() +
  theme(legend.position = 'bottom',
        legend.text = element_text(angle = 30)) +
  ggtitle('Power Plants Total PM2.5 Emissions - Census Tract Level - InMAP (µg/m3)') +
  theme(plot.title = element_text(hjust = 0.5))

### virginia centroid concentration
virginia_counties$label_point <- sf::st_centroid(virginia_counties$geometry)


### Virginia PM2.5 emissions plot with county names
p <- ggplot() +
  geom_sf(data = tracts_exp_totPM25_virginia, aes(fill = TotalPM25), size = 0, alpha = .9, color = NA) +
  geom_sf(data = virginia_counties, fill = NA, color = "grey", size = 0.5) +
  scale_fill_viridis_c(option = 'magma', limits = c(0, max(tracts_exp_totPM25_tracts$TotalPM25)), direction = -1, oob = scales::squish, alpha = 0.9) +
  expand_limits(fill = 0) +
  theme_minimal() +
  theme(legend.position = 'bottom',
        legend.text = element_text(angle = 30)) +
  ggtitle('Power Plants Total PM2.5 Emissions - Census Tract Level - InMAP (µg/m3)') +
  theme(plot.title = element_text(hjust = 0.5),
        axis.title.x = element_blank(),  # Remove x-axis title
        axis.title.y = element_blank())  # Remove y-axis title

# Add annotations for county names with conditional coloring
p + geom_sf_text(data = virginia_counties, 
                 aes(label = NAMELSADCO, geometry = label_point, 
                     color = ifelse(NAMELSADCO == "Pittsylvania", "white", "black")),
                 inherit.aes = FALSE, # Important to avoid inheriting unrelated aesthetics
                 size = 3, nudge_y = 0.01, check_overlap = TRUE) +
  scale_color_identity()  # Use actual color names provided in aes()



# Census Tract Virginia specific plot threshholds
tracts_exp_totPM25_virginia_thresh <- tracts_exp_totPM25_virginia %>%
  mutate(
    category = case_when(
      TotalPM25 < 0.01 ~ "<0.01",
      TotalPM25 >= 0.01 & TotalPM25 < 0.05 ~ "0.01-0.05",
      TotalPM25 >= 0.05 & TotalPM25 < 0.1 ~ "0.05-0.1",
      TotalPM25 >= 0.1 ~ ">=0.1",
      TRUE ~ NA_character_
    )
  )

# Define colors corresponding to 'magma' or similar feel
colors <- c("<0.01" = "lightyellow", 
            "0.01-0.05" = "orange", 
            "0.05-0.1" = "darkred", 
            ">=0.1" = "black")


tracts_exp_totPM25_virginia_thresh$category <- factor(tracts_exp_totPM25_virginia_thresh$category,
                                                      levels = c("<0.01", "0.01-0.05", "0.05-0.1", ">=0.1"))


p <-  ggplot(tracts_exp_totPM25_virginia_thresh, aes(fill = category)) +
    geom_sf(size = 0, alpha = .9, color = NA) +
    geom_sf(data = virginia_counties, fill = NA, color = "grey", size = 0.5) +
    scale_fill_manual(values = colors, name = "µg/m3") +
    theme_minimal() +
    theme(
      legend.position = c(0.1, 0.8),  # Use numeric values to place legend inside the plot
      legend.justification = c(0.1, 0.8),  # Aligns the top-right of the legend with the top-right of its position
      legend.box.just = "right",  # Anchor the legend box at the right side
      legend.margin = margin(t = -12, r = 10, b = 0, l = 0, unit = "pt"),  # Adjust top margin to move legend inside
      legend.title = element_text(size = 12), 
      legend.text = element_text(size = 10),
      legend.box.margin = margin(t = 0, r = 0, b = 0, l = 0, unit = "pt"),  # Adjust the box margin around the legend
      legend.background = element_rect(fill = "transparent", colour = NA)  # Optional: make legend background transparent
    ) +
    ggtitle('Power Plants Total PM2.5 Emissions - Census Tract Level - InMAP') +
    theme(plot.title = element_text(hjust = 0.5),
          axis.title.x = element_blank(),  # Remove x-axis title
          axis.title.y = element_blank())

# Add annotations for county names with conditional coloring
p + geom_sf_text(data = virginia_counties, 
                 aes(label = NAMELSADCO, geometry = label_point, 
                     color = ifelse(NAMELSADCO == "Pittsylvania", "white", "black")),
                 inherit.aes = FALSE, # Important to avoid inheriting unrelated aesthetics
                 size = 3, nudge_y = 0.01, check_overlap = TRUE) +
  scale_color_identity()  # Use actual color names provided in aes()




tracts_exp_totPM25_virginia[order(-tracts_exp_totPM25_virginia$TotalPM25),]

tracts_exp_totPM25_virginia = tracts_exp_totPM25_virginia %>% arrange(desc(TotalPM25)) 
tracts_exp_totPM25_virginia

#make zooomed plot
virginia_ncarolina <- us.sf[us.sf$state_name %in% c('Virginia', 'North Carolina'), ]

tracts_exp_totPM25_tracts

#####plot totPM25 ONLY ABOVE ZERO ######
tracts_exp_totPM25_above_zero = tracts_exp_totPM25_tracts[(tracts_exp_totPM25_tracts$TotalPM25>0.01),]

ggplot( tracts_exp_totPM25_above_zero,
        aes( fill =  TotalPM25)) +
  geom_sf( size = 0, alpha = 1, linewidth=.05, color=NA) +
  geom_sf( data = virginia_ncarolina, fill = 'NA', size = .5, linewidth=.05, color='black') +
  #scale_fill_gradient( high = 'black', low = 'lightyellow',
  #limits = c(0,1), 
  #                  oob = scales::squish) +
  scale_fill_viridis_c(option='magma',limits = c(0,max(tracts_exp_totPM25_tracts$TotalPM25)),oob = scales::squish, alpha =0.9)+
  
  expand_limits( fill = 0) +
  theme_minimal() +
  theme( legend.position = 'bottom',
         legend.text = element_text( angle = 30))  +
  ggtitle('') +
  theme(plot.title = element_text(hjust = 0.5))


### inverted magma plot
ggplot(tracts_exp_totPM25_above_zero, aes(fill = TotalPM25)) +
  geom_sf(size = 0, alpha = 1, color = NA) +  # Set alpha to 1 for full opacity
  geom_sf(data = virginia_ncarolina, fill = NA, size = .5, linewidth = .05, color = 'black') +
  scale_fill_viridis_c(option = 'magma', limits = c(0, max(tracts_exp_totPM25_tracts$TotalPM25)), direction = -1, oob = scales::squish, alpha = 0.9) +
  expand_limits(fill = 0) +
  theme_minimal() +
  theme(
    legend.position = 'bottom',
    legend.text = element_text(angle = 30)
  ) +
  ggtitle('Power Plants Total PM2.5 Emissions - InMAP (µg/m3)') +
  theme(plot.title = element_text(hjust = 0.5))


### virginia north carolina df
tracts_exp_totPM25_virginia_ncarolina = tracts_exp_totPM25_tracts[
  tracts_exp_totPM25_tracts$STATE_NAME %in% c('Virginia', 'North Carolina'),]

# Virginia data aggregated df by county
virginia_northcarolina_counties <- tracts_exp_totPM25_virginia_ncarolina %>%
  group_by(NAMELSADCO) %>%
  summarize(geometry = st_union(geometry), .groups = "drop")

virginia_northcarolina_counties <- virginia_northcarolina_counties %>%
  mutate(NAMELSADCO = gsub(" County", "", NAMELSADCO))

### virginia north carolina centroid concentration
virginia_northcarolina_counties$label_point <- sf::st_centroid(virginia_northcarolina_counties$geometry)


# Aggregate data and calculate label points using st_point_on_surface
virginia_northcarolina_counties <- tracts_exp_totPM25_virginia_ncarolina %>%
  group_by(NAMELSADCO) %>%
  summarize(geometry = st_union(geometry), .groups = "drop") %>%
  mutate(NAMELSADCO = gsub(" County", "", NAMELSADCO)) %>%
  mutate(label_point = st_point_on_surface(geometry))

virginia_northcarolina_counties <- tracts_exp_totPM25_virginia_ncarolina %>%
  group_by(NAMELSADCO, STUSPS, STATE_NAME) %>%
  summarize(geometry = st_union(geometry), .groups = "drop") %>%
  mutate(NAMELSADCO = gsub(" County", "", NAMELSADCO)) %>%
  mutate(label_point = st_point_on_surface(geometry)) %>%
  # Conditionally append "_STUSPS" to the county names "Halifax" and "Mecklenburg"
  mutate(NAMELSADCO = if_else(NAMELSADCO %in% c("Halifax", "Mecklenburg"), 
                              paste(NAMELSADCO, STUSPS, sep = "_"), 
                              NAMELSADCO))


# Plotting code
p <- ggplot() +
  geom_sf(data = tracts_exp_totPM25_virginia_ncarolina, aes(fill = TotalPM25), size = 0, alpha = .9, color = NA) +
  geom_sf(data = virginia_northcarolina_counties, fill = NA, color = "grey", size = 0.5) +
  scale_fill_viridis_c(option = 'magma', limits = c(0, max(tracts_exp_totPM25_tracts$TotalPM25)), direction = -1, oob = scales::squish, alpha = 0.9) +
  expand_limits(fill = 0) +
  theme_minimal() +
  theme(legend.position = 'bottom', legend.text = element_text(angle = 30)) +
  ggtitle('Power Plants Total PM2.5 Emissions - Census Tract Level - InMAP (µg/m3)') +
  theme(plot.title = element_text(hjust = 0.5), axis.title.x = element_blank(), axis.title.y = element_blank())


p + 
  geom_sf_text(data = virginia_northcarolina_counties %>%
                 mutate(NAMELSADCO = if_else(NAMELSADCO == "Halifax_VA", "Halifax", NAMELSADCO)) %>% 
                 filter(NAMELSADCO == "Pittsylvania"), 
               aes(label = NAMELSADCO, geometry = label_point),
               color = "white", fontface = "bold", size = 2.4, 
               check_overlap = FALSE, nudge_y = -0.02, nudge_x = 5) +  # Adjust nudge parameters as needed
  geom_sf_text(data = virginia_northcarolina_counties %>%
                 mutate(NAMELSADCO = if_else(NAMELSADCO == "Halifax_VA", "Halifax", NAMELSADCO)) %>% 
                 filter(!(NAMELSADCO %in% c("Pittsylvania"))), 
               aes(label = NAMELSADCO, geometry = label_point),
               size = 2.4, check_overlap = TRUE)


### Virginia North Carolina threshold plot

# Creating categories based on PM2.5 levels
tracts_exp_totPM25_virginia_ncarolina_thresh <- tracts_exp_totPM25_virginia_ncarolina %>%
  mutate(
    category = case_when(
      TotalPM25 < 0.01 ~ "<0.01",
      TotalPM25 >= 0.01 & TotalPM25 < 0.05 ~ "0.01-0.05",
      TotalPM25 >= 0.05 & TotalPM25 < 0.1 ~ "0.05-0.1",
      TotalPM25 >= 0.1 ~ ">=0.1",
      TRUE ~ NA_character_  # Handle any data outside the specified ranges
    )
  ) %>%
  mutate(category = factor(category, levels = c("<0.01", "0.01-0.05", "0.05-0.1", ">=0.1")))

# Define colors for each category
colors <- c("<0.01" = "lightyellow", 
            "0.01-0.05" = "orange", 
            "0.05-0.1" = "darkred", 
            ">=0.1" = "black")

# threshold plot VA NC

tracts_exp_totPM25_virginia_thresh$category <- factor(tracts_exp_totPM25_virginia_thresh$category,
                                                      levels = c("<0.01", "0.01-0.05", "0.05-0.1", ">=0.1"))


p <-  ggplot(tracts_exp_totPM25_virginia_ncarolina_thresh, aes(fill = category)) +
  geom_sf(size = 0, alpha = .9, color = NA) +
  geom_sf(data = virginia_northcarolina_counties, fill = NA, color = "grey", size = 0.5) +
  geom_sf(data = virginia_ncarolina, fill = NA, size = .5, color = 'black') +
  scale_fill_manual(values = colors, name = "µg/m3") +
  theme_minimal() +
  theme(
    legend.position = c(0.1, 0.8),  # Use numeric values to place legend inside the plot
    legend.justification = c(0.1, 0.8),  # Aligns the top-right of the legend with the top-right of its position
    legend.box.just = "right",  # Anchor the legend box at the right side
    legend.margin = margin(t = -12, r = 10, b = 0, l = 0, unit = "pt"),  # Adjust top margin to move legend inside
    legend.title = element_text(size = 12), 
    legend.text = element_text(size = 10),
    legend.box.margin = margin(t = 0, r = 0, b = 0, l = 0, unit = "pt"),  # Adjust the box margin around the legend
    legend.background = element_rect(fill = "transparent", colour = NA)  # Optional: make legend background transparent
  ) +
  ggtitle('Power Plants Total PM2.5 Emissions - Census Tract Level - InMAP') +
  theme(plot.title = element_text(hjust = 0.5),
        axis.title.x = element_blank(),  # Remove x-axis title
        axis.title.y = element_blank())

p + 
  geom_sf_text(data = virginia_northcarolina_counties %>% 
                 mutate(NAMELSADCO = if_else(NAMELSADCO == "Halifax_VA", "Halifax", NAMELSADCO)), 
               aes(label = NAMELSADCO, geometry = label_point, 
                   color = ifelse(NAMELSADCO == "Pittsylvania", "white", "black")),
               inherit.aes = FALSE,  # Ensure it does not inherit other aesthetics
               size = 2.8, nudge_y = 0.01, check_overlap = TRUE) +
  scale_color_identity()  # Apply the colors as defined in the color aesthetic







quantile(tracts_exp_sf_totPM25_finest_res_corrected_FINAL$TotalPM25)
hist(tracts_exp_sf_totPM25_finest_res_corrected_FINAL_above_zero$TotalPM25 )


### zoomed in plot for census tracts with a level of PM2.5 >0.01

tracts_exp_totPM25_above_zero

# Virginia data aggregated df by county
above_zero_counties <- tracts_exp_totPM25_above_zero %>%
  group_by(NAMELSADCO) %>%
  summarize(geometry = st_union(geometry), .groups = "drop")

above_zero_counties <- above_zero_counties %>%
  mutate(NAMELSADCO = gsub(" County", "", NAMELSADCO))

### virginia north carolina centroid concentration
above_zero_counties$label_point <- sf::st_centroid(above_zero_counties$geometry)


# Aggregate data and calculate label points using st_point_on_surface
above_zero_counties <- tracts_exp_totPM25_above_zero %>%
  group_by(NAMELSADCO, STUSPS, STATE_NAME) %>%
  summarize(geometry = st_union(geometry), .groups = "drop") %>%
  mutate(NAMELSADCO = gsub(" County", "", NAMELSADCO)) %>%
  mutate(label_point = st_point_on_surface(geometry)) %>%
  # Conditionally append "_STUSPS" to the county names "Halifax" and "Mecklenburg"
  mutate(NAMELSADCO = if_else(NAMELSADCO %in% c("Halifax", "Mecklenburg"), 
                              paste(NAMELSADCO, STUSPS, sep = "_"), 
                              NAMELSADCO))


ggplot( tracts_exp_totPM25_above_zero,
        aes( fill =  TotalPM25)) +
  geom_sf( size = 0, alpha = .9, color = 'NA') +
  #geom_sf( data = us.sf, fill = NA, size = .5, linewidth=.05, color='black') +
  #scale_fill_gradient( high = '#2a1c0e', low = 'moccasin',
  #                     limits = c(0,1), 
  #                  oob = scales::squish) +
  scale_fill_viridis_c(option='magma',direction = 1,limits = c(0,max(tracts_exp_totPM25_tracts$TotalPM25)),oob = scales::squish, alpha =0.9)+
  
  expand_limits( fill = 0) +
  #theme_minimal() +
  theme(axis.text.x = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks = element_blank(),
        rect = element_blank())+
  theme( legend.position = 'bottom',
         legend.text = element_text( angle = 30))  +
  ggtitle('Power Plants Total PM2.5 Emissions - Census Tract Level - InMAP (µg/m3)') +
  theme(plot.title = element_text(hjust = 0.5))


#####plot for paper - final reverse magma

p <- ggplot(tracts_exp_totPM25_above_zero, aes(fill = TotalPM25)) +
  geom_sf(size = 0, alpha = 0.9, color = NA) +
  geom_sf(data = above_zero_counties, fill = NA, color = "grey", size = 0.5) +
  scale_fill_viridis_c(option = 'magma', direction = -1, limits = c(0, max(tracts_exp_totPM25_tracts$TotalPM25)), oob = scales::squish, alpha = 0.9) +
  theme_minimal() +
  theme(
    #axis.text.x = element_blank(),  # Remove x-axis text
    #axis.text.y = element_blank(),  # Remove y-axis text
    axis.ticks = element_blank(),   # Remove axis ticks
    axis.title.x = element_blank(), # Remove x-axis title
    axis.title.y = element_blank(), # Remove y-axis title
    axis.line = element_blank(),    # Remove axis line
    plot.title = element_text(hjust = 0.5),
    legend.position = 'bottom',
    legend.text = element_text(angle = 30)
  ) +
  ggtitle('Power Plants Total PM2.5 Emissions - Census Tract Level - InMAP (µg/m3)')

# Adjusting ggplot code to include Mecklenburg_VA renaming and adding the plot
p + geom_sf_text(data = above_zero_counties %>%
                   mutate(NAMELSADCO = case_when(
                     NAMELSADCO == "Halifax_VA" ~ "Halifax",
                     NAMELSADCO == "Mecklenburg_VA" ~ "Mecklenburg",
                     TRUE ~ NAMELSADCO
                   )), 
                 aes(label = NAMELSADCO, geometry = label_point,
                     color = ifelse(NAMELSADCO == "Pittsylvania", "white", "black")),
                 inherit.aes = FALSE,  # Ensure it does not inherit other aesthetics
                 size = 3, nudge_y = 0.01, check_overlap = TRUE) +
  scale_color_identity()  # Apply the colors as defined in the color aesthetic



### threshold plot
# Categorize the TotalPM25 data into specific ranges
tracts_exp_totPM25_above_zero_thresh <- tracts_exp_totPM25_above_zero %>%
  mutate(
    category = case_when(
      TotalPM25 < 0.01 ~ "<0.01",
      TotalPM25 >= 0.01 & TotalPM25 < 0.05 ~ "0.01-0.05",
      TotalPM25 >= 0.05 & TotalPM25 < 0.1 ~ "0.05-0.1",
      TotalPM25 >= 0.1 ~ ">=0.1",
      TRUE ~ NA_character_  # Handle any data outside the specified ranges
    )
  ) %>%
  mutate(category = factor(category, levels = c("<0.01", "0.01-0.05", "0.05-0.1", ">=0.1")))

# Define colors for each category
colors <- c("<0.01" = "lightyellow", 
            "0.01-0.05" = "darkorange", 
            "0.05-0.1" = "darkred", 
            ">=0.1" = "black")

p <- ggplot(tracts_exp_totPM25_above_zero_thresh, aes(fill = category)) +
  geom_sf(size = 0.01, alpha = .9, color = "grey") + 
  geom_sf(data = above_zero_counties, fill = NA, color = "black", size = 0.5) +
  geom_sf(size = 0, alpha = .9, color = NA) +  # Draw the filled shapes with no borders and slight transparency
  scale_fill_manual(values = colors, name = "µg/m3") +
  theme_minimal() +
  theme(
    legend.position = c(1, 1),  # Numeric values for precise control within the plot area
    legend.justification = c(1, 1),  # Top right of the legend aligns with the top-right corner of the plot area
    legend.box.just = "right",  # Anchor the legend box on the right side
    legend.margin = margin(t = -10, r = 10, b = 0, l = 0, unit = "pt"),  # Adjust margins to move legend inside the plot
    legend.title = element_text(size = 12), 
    legend.text = element_text(size = 10),
    legend.box.margin = margin(t = 0, r = 0, b = 0, l = 0, unit = "pt"),  # Minimal margin around legend
    legend.background = element_rect(fill = "transparent", colour = NA),  # Transparent background for the legend
    #axis.text.x = element_blank(),  # Remove x-axis text
    #axis.text.y = element_blank(),  # Remove y-axis text
    axis.title.x = element_blank(), # Remove x-axis title
    axis.title.y = element_blank(), # Remove y-axis title
    #axis.ticks = element_blank(),   # Remove axis ticks
    #axis.line = element_blank(),    # Remove axis line
    plot.title = element_text(hjust = 0.5)  # Center-justify the plot title
  ) +
  ggtitle('Power Plants Total PM2.5 Emissions - Census Tract Level - InMAP')

p + 
  geom_sf_text(data = above_zero_counties %>% 
                 mutate(NAMELSADCO = case_when(
                   NAMELSADCO == "Halifax_VA" ~ "Halifax",
                   NAMELSADCO == "Mecklenburg_VA" ~ "Mecklenburg",
                   TRUE ~ NAMELSADCO
                 )), 
               aes(label = NAMELSADCO, geometry = label_point, 
                   color = ifelse(NAMELSADCO == "Pittsylvania", "white", "black")),
               inherit.aes = FALSE,  # Ensure it does not inherit other aesthetics
               size = 3, nudge_y = 0.01, check_overlap = TRUE) +
  scale_color_identity()  # Apply the colors as defined in the color aesthetic










## demographics

####### Demographics at tract level ######
library(data.table)
install.packages('R.utils')
library(R.utils)
library(dplyr)

demogrphics_tracts_all = fread("insert_data_path/2022_tract_acs5.csv.gz")
demogrphics_tracts_all

demogrphics_tracts_all$pct_age_above_65 <- 
  demogrphics_tracts_all$pct_age_65_to_66 + 
  demogrphics_tracts_all$pct_age_67_to_69 + 
  demogrphics_tracts_all$pct_age_70_to_74 + 
  demogrphics_tracts_all$pct_age_75_to_79 + 
  demogrphics_tracts_all$pct_age_80_to_84 + 
  demogrphics_tracts_all$pct_age_over_85

tracts_exp_totPM25_above_zero = tracts_exp_totPM25_tracts[(tracts_exp_totPM25_tracts$TotalPM25>0.01),]

demogrphics_tracts = dplyr::select(demogrphics_tracts_all, GEOID, population, pct_age_above_65, pct_white, pct_black, pct_asian, pct_hispanic, pct_native, ethnic_fractionalization, med_household_income,med_family_income,pct_poverty,med_property_value)
demogrphics_tracts

demogrphics_tracts = demogrphics_tracts_all %>%
  dplyr::select(GEOID, population,pct_age_above_65, pct_white, pct_black, pct_asian, pct_hispanic, pct_native, ethnic_fractionalization, med_household_income,med_family_income,pct_poverty,med_property_value)

demogrphics_tracts$GEOID = as.numeric(demogrphics_tracts$GEOID)

demogrphics_tracts 
tracts_sf$GEOID = as.numeric(tracts_sf$GEOID)

tracts_sf_dem <- tracts_sf %>% 
  left_join(demogrphics_tracts, by='GEOID')

tracts_sf_dem
va_data <- tracts_sf_dem %>% filter(STUSPS == "VA")
va_data
us.sf.dem
tracts_exp_totPM25_above_zero$GEOID = as.numeric(tracts_exp_totPM25_above_zero$GEOID)


demogrphics_tracts$pop_white = demogrphics_tracts$population*demogrphics_tracts$pct_white
demogrphics_tracts$pop_black = demogrphics_tracts$population*demogrphics_tracts$pct_black
demogrphics_tracts$pop_hispanic = demogrphics_tracts$population*demogrphics_tracts$pct_hispanic
demogrphics_tracts


exposure_all_black_white_hispanic <- tracts_exp_totPM25_above_zero %>% 
  left_join(demogrphics_tracts, by='GEOID')


demogrphics_tracts
sum(exposure_all_black_white_hispanic$population)
tracts_exp_totPM25_tracts[(tracts_exp_totPM25_tracts$TotalPM25>0.01),]

over_0.1 <- tracts_exp_totPM25_tracts[(tracts_exp_totPM25_tracts$TotalPM25>0.1),]

over_0.1 <- over_0.1 %>% 
  left_join(demogrphics_tracts, by='GEOID')

sum(over_0.1$population)

sum(exposure_all_black_white_hispanic$pop_hispanic)
sum(exposure_all_black_white_hispanic$pop_black)
sum(exposure_all_black_white_hispanic$pop_white)

colSums(is.na(exposure_all_black_white_hispanic))

sum(exposure_all_black_white_hispanic$pop_white, na.rm = TRUE)
sum(exposure_all_black_white_hispanic$pop_black,na.rm = TRUE)
sum(exposure_all_black_white_hispanic$pop_hispanic, na.rm = TRUE)

weighted.mean(exposure_all_black_white_hispanic$pct_poverty, 
              exposure_all_black_white_hispanic$population, 
              na.rm = TRUE)

weighted.mean(over_0.1$pct_poverty, 
              over_0.1$population, 
              na.rm = TRUE)

weighted.mean(over_0.1$pct_white, 
              over_0.1$population, 
              na.rm = TRUE)

weighted.mean(over_0.1$pct_black, 
              over_0.1$population, 
              na.rm = TRUE)

weighted.mean(over_0.1$pct_hispanic, 
              over_0.1$population, 
              na.rm = TRUE)

weighted.mean(over_0.1$pct_asian, 
              over_0.1$population, 
              na.rm = TRUE)

weighted.mean(over_0.1$pct_age_above_65, 
              over_0.1$population, 
              na.rm = TRUE)


mean(over_0.1$med_household_income)
mean(over_0.1$med_property_value)