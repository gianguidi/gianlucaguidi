# Power Plant Emissions to Health Impact Pipeline

This repository provides a step-by-step pipeline to estimate the health impacts of pollution from an individual power plant using emission characteristics, dispersion modeling of pollutants (InMAP), and public health burden tools.

---

## Overview

Given a power plant's location, capacity, and emissions factors, this pipeline:

- Estimates annual emissions (PM2.5, NOx, SO₂, CO₂)
- Models spatial dispersion of pollutants using InMAP
- Converts InMAP results to census-level estimates
- Uses COBRA to estimate health impacts

---

## Repository Structure
- README.md — Project overview and instructions
- scripts/ — R scripts for preprocessing, postprocessing, and health analysis
- config/ — InMAP TOML configuration file for reference (specific files saved to output)
- data/ — Input data (emissions, shapefiles, census)
- output/ — Outputs from InMAP and postprocessing for specific model run

---

## Workflow

### 1. Identify Power Plant Characteristics

Collect:

- 📍 Location: Latitude, Longitude
- ⚡ Power Capacity: Megawatts (MW)
- 📏 Stack Height: Meters
- 🌫️ Emissions Factors:
  - PM2.5
  - NOx
  - SO₂
  - CO₂

**Annual Emissions** = Capacity × 8,760 hrs/year × Uptime × Emissions Factor

### 2. Run Preprocessing Script

The script will:

- Create a folder for the run: `YY.MM.DD_identifier`
- Generate a shapefile with the power plant and calculated emissions
- Format inputs for InMAP

**Outputs:**

- `powerplant.shp`, `.dbf`, `.shx`, `.prj`
- Figure showing location of powerplant 

### 3. Run InMAP script (1_run_inmap.R)

This script automatically launches the InMAP model from within R and does not require a manual system call. It reads the emissions shapefile and run directory produced in 0_pre_process.R, constructs the InMAP configuration file (Config_<identifier>.toml), and then executes InMAP in steady-state mode through the R interface.

The script handles:
	-	Generating the TOML configuration file (paths, emissions input, evaluation data, output directory)
  - Setting key model options (grid/mesh settings, pollutants, run mode)
  - Calling the InMAP executable directly from R using the user-supplied path to the binary

No additional terminal commands are required; running the script is sufficient.

**Outputs:**
	•	InMAP concentration fields (*.shp)
	•	Model log files and messages
	•	The configuration file used for reproducibility (Config_<identifier>.toml)

**How it works under the hood:**

InMAP uses a pre-computed “evaldata” package (meteorology, chemistry, population, baseline concentrations) for a fixed reference year. It reads your emissions shapefile, applies annual‐average transport and reaction rates, and outputs the incremental pollutant fields—no live weather or census lookups are required.

### 4. Postprocess Model Output

- Load 2022 ACS 5-year census tract data  
- Convert InMAP gridded results to tract-level concentrations  
- Visualize and summarize:  
  - Maps of pollutant concentrations  
  - Exposure distribution summaries


### 5. Health Impact Analysis (COBRA)

Use the [EPA COBRA Tool](https://www.epa.gov/cobra) (Excel or web):

**Inputs:**  
- State  
- Sector (pollution type)  
- Annual emissions (PM2.5, SO₂, NOx)  

**Outputs:**  
- Premature mortality estimates  
- Asthma case counts  
- Economic damage estimates

---

## ⚙️ Requirements
**Software**
- R (≥ 4.0)
- InMAP (e.g. inmap_v1.6.1)
- EPA COBRA Tool (Excel or web version)

**R Packages**
- sf, data.table, tidyverse, here, ggplot2


